# 从文件读写到分布式存储与 3FS

阅读全文：tutorial.md

运行实验：python3 labs/对应文件名.py
