"""Deterministic buffer-lifetime demonstration, not a real DMA engine."""
import asyncio


async def delayed_write(source, started, release):
    started.set()
    await release.wait()
    return bytes(source)


async def scenario(reuse_early):
    source = bytearray(b"AAAA")
    started = asyncio.Event()
    release = asyncio.Event()
    task = asyncio.create_task(delayed_write(source, started, release))
    await started.wait()
    if reuse_early:
        source[:] = b"BBBB"
    release.set()
    observed = await task
    if not reuse_early:
        source[:] = b"BBBB"
    return observed


async def main():
    wrong = await scenario(True)
    correct = await scenario(False)
    assert wrong == b"BBBB"
    assert correct == b"AAAA"
    print("reused before completion:", wrong.decode())
    print("reused after completion: ", correct.decode())
    print("PASS: retaining a buffer includes retaining its required contents")


if __name__ == "__main__":
    asyncio.run(main())
