"""In-process teaching model: immutable chunks, all replicas, manifest publish.

No network, disk durability, election, CRAQ, distributed transaction, or automatic
garbage collection is implemented. A local lock serializes writers. Receipts and
manifests are volatile. Do not use this as a production storage implementation.
"""
import hashlib
from dataclasses import dataclass


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Node:
    def __init__(self, name):
        self.name = name
        self.online = True
        self.objects = {}

    def put(self, key, data):
        if not self.online:
            raise ConnectionError(self.name)
        if key in self.objects and self.objects[key] != data:
            raise ValueError("immutable object identity reused")
        self.objects[key] = data


@dataclass(frozen=True)
class Chunk:
    key: tuple
    length: int
    checksum: str


@dataclass(frozen=True)
class Manifest:
    version: int
    length: int
    checksum: str
    chunks: tuple


class Store:
    def __init__(self):
        import threading
        self.nodes = [Node("A"), Node("B"), Node("C")]
        self.manifests = {}
        self.receipts = {}
        self.next_version = 0
        self.writer_lock = threading.Lock()

    def write(self, name, data, request_id, lose_response=False):
        fingerprint = (name, digest(data))
        with self.writer_lock:
            if request_id in self.receipts:
                old_fingerprint, version = self.receipts[request_id]
                if old_fingerprint != fingerprint:
                    raise ValueError("same request ID with different operation")
                return version
            self.next_version += 1
            version = self.next_version
            chunks = []
            for index, offset in enumerate(range(0, len(data), 4)):
                part = data[offset:offset + 4]
                key = (name, version, index)
                for node in self.nodes:
                    node.put(key, part)
                chunks.append(Chunk(key, len(part), digest(part)))
            # This local lock and in-process state model a single atomic publish.
            self.manifests[name] = Manifest(
                version, len(data), digest(data), tuple(chunks)
            )
            self.receipts[request_id] = (fingerprint, version)
            if lose_response:
                raise TimeoutError("committed, but response was lost")
            return version

    def read(self, name):
        # One immutable manifest snapshot; do not reread it for every chunk.
        manifest = self.manifests[name]
        parts = []
        for chunk in manifest.chunks:
            valid = None
            for node in self.nodes:
                if not node.online:
                    continue
                part = node.objects.get(chunk.key)
                if (part is not None and len(part) == chunk.length
                        and digest(part) == chunk.checksum):
                    valid = part
                    break
            if valid is None:
                raise IOError("no valid replica")
            parts.append(valid)
        data = b"".join(parts)
        if len(data) != manifest.length or digest(data) != manifest.checksum:
            raise IOError("manifest validation failed")
        return data


def expect_error(error_type, operation):
    try:
        operation()
    except error_type:
        return
    raise AssertionError(f"expected {error_type.__name__}")


def main():
    store = Store()
    v1 = store.write("file", b"old-data", "request-1")
    assert store.read("file") == b"old-data"
    store.nodes[1].online = False
    expect_error(ConnectionError, lambda: store.write(
        "file", b"new-data", "request-2"))
    assert store.manifests["file"].version == v1
    assert store.read("file") == b"old-data"
    store.nodes[1].online = True
    expect_error(TimeoutError, lambda: store.write(
        "file", b"new-data", "request-2", lose_response=True))
    version = store.manifests["file"].version
    assert store.write("file", b"new-data", "request-2") == version
    expect_error(ValueError, lambda: store.write(
        "file", b"different", "request-2"))
    key = store.manifests["file"].chunks[0].key
    store.nodes[0].objects[key] = b"BAD!"
    assert store.read("file") == b"new-data"
    for node in store.nodes:
        node.objects[key] = b"BAD!"
    expect_error(IOError, lambda: store.read("file"))
    store.write("empty", b"", "request-empty")
    assert store.read("empty") == b""
    print("PASS: normal read/write, failed publish, lost response, retry dedup,")
    print("request conflict, corrupt-replica fallback, all-corrupt failure, empty file")


if __name__ == "__main__":
    main()
