"""Observe path replacement and open-file identity; no third-party packages."""
import os
import tempfile
from pathlib import Path


def main():
    with tempfile.TemporaryDirectory(prefix="storage-identity-") as directory:
        root = Path(directory)
        target = root / "data.bin"
        replacement = root / "next.bin"
        target.write_bytes(b"old-version")
        fd = os.open(target, os.O_RDONLY)
        try:
            old_inode = os.fstat(fd).st_ino
            replacement.write_bytes(b"new-version")
            os.replace(replacement, target)
            old_data = os.pread(fd, 64, 0)
            new_data = target.read_bytes()
            assert old_data == b"old-version"
            assert new_data == b"new-version"
            assert os.fstat(fd).st_ino == old_inode
            target.unlink()
            assert not target.exists()
            assert os.pread(fd, 64, 0) == b"old-version"
            print("old fd reads:", old_data.decode())
            print("new path reads:", new_data.decode())
            print("PASS: an open fd retains its object after replacement/unlink")
        finally:
            os.close(fd)


if __name__ == "__main__":
    main()
