"""Single-file publication pattern for Linux local filesystems.

Normal execution verifies bytes, not power-loss durability. The filesystem and
storage must implement the documented fsync/rename semantics.
"""
import hashlib
import os
import tempfile
from pathlib import Path


def durable_replace(target: Path, data: bytes):
    fd, temp_name = tempfile.mkstemp(prefix=".pending-", dir=target.parent)
    try:
        remaining = memoryview(data)
        while remaining:
            written = os.write(fd, remaining)
            if written <= 0:
                raise OSError("write made no progress")
            remaining = remaining[written:]
        os.fsync(fd)
        os.close(fd)
        fd = -1
        os.replace(temp_name, target)
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        parent_fd = os.open(target.parent, flags)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    finally:
        if fd >= 0:
            os.close(fd)
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def main():
    with tempfile.TemporaryDirectory(prefix="storage-publish-") as directory:
        target = Path(directory) / "published.bin"
        for data in [b"version-1\n", b"version-2\n" * 1024, b""]:
            durable_replace(target, data)
            assert target.read_bytes() == data
        print("sha256:", hashlib.sha256(target.read_bytes()).hexdigest())
        print("PASS: publication sequence and byte checks completed")
        print("This is not a power-loss or crash-consistency proof.")


if __name__ == "__main__":
    main()
