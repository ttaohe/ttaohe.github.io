# Private publisher 0.2.0：公开验证说明

这是可离线审阅、按固定版本和哈希校验的源码交付。此公开版不包含生产数据、私有备份、实际 SSH 目标、生产登录账号、UID、密钥路径、电脑主机名或运行日志。脚本使用的服务名、账号名、目录和回环地址均为通用安装默认值，不是访问凭据。

## 固定源码包

文件：`private-publisher-0.2.0.tar.gz`，大小 23,713 字节。

SHA-256：`7e7edbe9996e5ec5958ac7fc7a350498a2706eeb9202751645d53f56c4448603`。

源码包白名单为 12 个文件：VERSION、MANIFEST.json、4 个 Python 核心文件、PORTABLE.md 和 5 个通用 shell 脚本。MANIFEST.json 记录各源码文件的 SHA-256；两次确定性构建哈希一致。包不含测试数据、生产数据库、备份、配置凭据、真实路径或现场日志。本次只制作固定源码文件，不代表已建立公共代码仓库或公开下载链接。

可用 Python 标准库离线核验，无需执行包内脚本：

```python
import hashlib, json, tarfile
from pathlib import Path
archive = Path('private-publisher-0.2.0.tar.gz')
expected = '7e7edbe9996e5ec5958ac7fc7a350498a2706eeb9202751645d53f56c4448603'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
with tarfile.open(archive) as bundle:
    manifest = json.load(bundle.extractfile('MANIFEST.json'))
    assert manifest['version'] == '0.2.0'
    assert set(bundle.getnames()) == set(manifest['files']) | {'MANIFEST.json'}
    for name, digest in manifest['files'].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == digest
print('Verified 0.2.0 source bundle')
```

## 真实公开统一 JSON

样例来自固定公开提交 `6fdfa533781642a69e8931df6eafaa10250e5938` 的 `lib/blog/content.json`，大小 12,972,715 字节，SHA-256 `ee516cbf6ad9da28e59c87724e57054e8efbfc1e80d12ea539a03f67bfc9d450`。统计为 7 篇文章、876 条日报、67 个实验。没有执行原站工作流；只使用内容和必要的安全类型定义。

实现按原始字节分块保存统一 JSON，并直接替换 posts、daily.reports[date]、experiments 中明确选中的版本。没有添加前端不认识的扩展字段。单条编辑只允许受控标量叶节点，稳定 slug/id 不变，复合对象与历史归档不能被整块覆盖。新日报只支持已有日期容器。

## 测试结果

本地完整测试 11 项全部通过，运行时间约 74.5 秒，包含：

- 无修改导出逐字节等同原公开文件，SHA-256 一致。
- 仅一篇文章标题修订后的全量 JSON 比较：其他条目、所有未知字段和历史归档、daily dates/columns/topicBars/issueMeta 不变。
- 未选新草稿、后续私有版本的哨兵内容不进入快照；明确选择的旧版本准确导出。
- 稳定 slug 修改、复合对象覆盖、重复版本选择、新身份冲突被拒绝。
- 公开内容变化后检测旧私有修订冲突；已创建请求保持固定基线和版本。
- 完整备份恢复后私有版本、请求、每站状态一致，恢复后的导出哈希与恢复前一致。
- 非预期 Host/Origin 写请求被拒绝，路径遍历返回 404，默认未选草稿，正文 HTML 被转义。
- 代码包确定性、逐文件哈希、隐私排除、shell 语法和安装计划检查通过。

生产数据没有放入源码包。测试样例和测试文件也未包含在本次代码包中，因此源码包本身不是可直接运行全套测试的测试发布包；上述结果是已完成工作的脱敏记录。

## 实际小服务器部署测试

在 Ubuntu 22.04、Python 3.10.12、1 核、约 454 MiB 内存、无 swap 的环境完成了有限回环部署测试。

完整真实公开文件导入、私有修订及选定导出、最大历史条目处理、备份恢复，以专用非 root 账号在 80 MiB 上限内完成；进程峰值 RSS 33,128,448 字节，约 31.6 MiB，耗时约 57.2 秒。最大公开历史条目 UI 预览的服务峰值 RSS 约 34.0 MiB。单次样例结果不保证未来容量上限、长期运行或高并发内存。

确认只绑定回环；经严格 SSH 主机密钥校验的临时隧道访问通过，完成后关闭。正常重启、一次受控故障自动重启、停止/启动、服务器备份恢复与同版本代码切换通过。仅一个版本安装过，跨版本兼容回滚尚未验证。服务未启用开机自启，原有服务保持运行，防火墙和公网访问未修改。

## SQLite 说明

本机 Python 实际链接 SQLite 3.43.2，测试服务器链接 SQLite 3.37.2；版本字符串不能单独证明发行版补丁回移情况，没有取得 WAL-reset 专项补丁证据，也没有升级系统。

实际实现为 journal_mode=delete、synchronous=FULL；单线程 UI 和进程级独占锁限制写者，CLI 维护先停 UI；一致性备份使用 SQLite backup API。拒绝 WAL 数据库，不执行 WAL checkpoint。

[SQLite 官方 WAL-reset 说明](https://www.sqlite.org/wal.html#wal_reset_bug)描述的是 WAL 模式、多连接写入/checkpoint 竞争，本实现不走该路径；不能据此宣称所有 SQLite 问题都已解决。

## 限制和交付边界

应用认证、自动多站发布及远端核验/重试、公开代码下载地址、完整网站渲染预览、加密异地/定时备份、附件、新日报日期和元数据管理、撤回删除、schema 迁移、资源长期配额及跨版本回滚仍未完成。回环不隔离同机其他本地进程，本版是通过现有 SSH 隧道访问的单用户原型。

换服务器需分别获取固定代码、通过私有通路恢复私有状态、自行配置现有 SSH；源码包不嵌入私有数据或 GitHub/Drive 凭据。公开博客或源码归档不能包含私有数据库、完整备份或现场连接配置。
