"""Reproducible allowlisted source/test archive; never include runtime state."""
import gzip
import hashlib
import io
import json
import re
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
version = (root / 'VERSION').read_text().strip()
files = ['VERSION','publisher.py','server.py','unified.py','unified_server.py','PORTABLE.md',
         'SOURCE_README.md','VALIDATION.public.md','MANIFEST.json','benchmark.py','benchmark_unified.py',
         'build_release.py','build_source_archive.py','scripts/install.sh','scripts/health.sh',
         'scripts/operations.sh','scripts/rollback.sh','scripts/fetch-code.sh','scripts/download_fixture.py',
         'tests/test_publisher.py','tests/test_server.py','tests/test_unified.py',
         'tests/test_unified_server.py','tests/test_release.py','tests/test_fixture_download.py']
for name in files:
    if (root/name).is_symlink(): raise ValueError('source symlinks not accepted')
manifest = {'version':version,'archive_kind':'source-tests',
            'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}}
manifest_bytes = (json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
target = root/'release'/('private-publisher-'+version+'-source-tests.tar.gz')
target.parent.mkdir(exist_ok=True)
with target.open('wb') as output, gzip.GzipFile(fileobj=output,mode='wb',mtime=0,filename='') as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
        for name in sorted(files+['SOURCE_MANIFEST.json']):
            data = manifest_bytes if name=='SOURCE_MANIFEST.json' else (root/name).read_bytes()
            text=data.decode('utf-8')
            for pattern in [r'/Users/[A-Za-z0-9_-]+',r'/home/[A-Za-z0-9_-]+',
                            r'\b[A-Za-z0-9_-]+\.local\b',r'/\.ssh/',r'-----BEGIN [A-Z ]*PRIVATE KEY-----']:
                if re.search(pattern,text): raise ValueError('non-public data in '+name)
            for address in re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b',text):
                if address!='127.0.0.1': raise ValueError('non-loopback IP in '+name)
            member=tarfile.TarInfo(name); member.size=len(data)
            member.mode=0o755 if name.endswith('.sh') else 0o644; member.mtime=0
            archive.addfile(member,io.BytesIO(data))
digest=hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix(target.suffix+'.sha256').write_text(digest+'  '+target.name+'\n')
print(target.name,target.stat().st_size,digest)
