"""Synthetic local workload only; never uses user content or server access."""
from pathlib import Path
import tempfile
from publisher import Store

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    store = Store(root / "private.sqlite3")
    revisions = []
    for i in range(100):
        _, revision = store.save("article", "Synthetic %s" % i, "x" * 4096)
        revisions.append(revision)
    for site in ["one", "two", "three", "four", "five"]:
        store.import_public(site, {"history": [{"opaque": "y" * 65536}]})
    request = store.request(revisions[:10], ["one", "two", "three", "four", "five"])
    for site in ["one", "two", "three", "four", "five"]:
        store.export(request, site, root / (site + ".json"))
    store.backup(root / "backup.zip")
    print("100 synthetic documents, 5 sites, 10 selected revisions; export and backup complete")
    print("SQLite bytes:", (root / "private.sqlite3").stat().st_size)
    store.close()
