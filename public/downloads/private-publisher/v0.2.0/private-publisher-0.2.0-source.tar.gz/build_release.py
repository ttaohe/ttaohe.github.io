"""Build reproducible code-only bundle; an explicit allowlist excludes data/config."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
version = (root / "VERSION").read_text().strip()
files = ["VERSION", "publisher.py", "server.py", "unified.py", "unified_server.py", "PORTABLE.md",
         "scripts/install.sh", "scripts/health.sh", "scripts/operations.sh", "scripts/rollback.sh", "scripts/fetch-code.sh"]
manifest = {"version": version, "files": {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}}
manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
(root / "MANIFEST.json").write_bytes(manifest_bytes)
target = root / "release" / ("private-publisher-" + version + ".tar.gz")
target.parent.mkdir(exist_ok=True)
with target.open("wb") as output, gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name in sorted(files + ["MANIFEST.json"]):
            data = manifest_bytes if name == "MANIFEST.json" else (root/name).read_bytes()
            item = tarfile.TarInfo(name); item.size = len(data)
            item.mode = 0o755 if name.endswith(".sh") else 0o644
            item.mtime = 0; archive.addfile(item, io.BytesIO(data))
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix(target.suffix + ".sha256").write_text(digest + "  " + target.name + "\n")
print(target.name, digest)
