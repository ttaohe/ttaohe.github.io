# Portable private publisher 0.2.0

This code-only bundle has no drafts, content fixtures, hostnames, SSH keys, credentials or real server configuration. It requires Linux, systemd and existing Python 3.10+ with SQLite. It never installs dependencies, opens public ports, creates authentication secrets or publishes to GitHub/Drive. The UI listens only on `127.0.0.1:8080` and must be reached through an existing, trusted SSH tunnel. Local processes that can access loopback can access the UI: this is a single-owner prototype without application authentication.

## Keep code, private state and credentials separate

1. **Code:** choose an explicitly approved public release bundle URL and its independently checked SHA-256. `scripts/fetch-code.sh HTTPS_BUNDLE_URL SHA256 NEW_DIRECTORY` fetches that version and verifies the archive before safe extraction. No public release URL exists yet; do not invent one or deploy arbitrary moving-branch code.
2. **Private state:** move the private backup separately over your approved private channel. Never commit or upload it into a public code release. Backups include all drafts, histories, baseline JSON chunks, publishing requests and results. They are not encrypted yet; only private owner-only storage is supported.
3. **Credentials:** separately configure existing SSH access yourself. GitHub/Drive authentication and automatic publishing are not implemented. There is nothing in this bundle that stores those credentials.

## Review and install

```sh
sh scripts/install.sh --plan
sudo sh scripts/install.sh --start
sudo sh /opt/private-publisher/current/scripts/operations.sh health
```

Installation is repeatable for the same version and manifest. It creates only the dedicated `privatepublisher` system account with nologin, managed code releases under `/opt/private-publisher`, owner-only state under `/var/lib/private-publisher`, and the independent `private-publisher.service`. Existing unrelated accounts or service units are rejected. No existing user service is stopped. If the managed service is running, stop it explicitly before reinstalling/switching code. Boot auto-start is not enabled; reboot persistence is a separate operator decision. The service uses `MemoryHigh=64M`, `MemoryMax=80M`, `CPUQuota=50%`, and one Python worker; limits do not guarantee that all future content fits in memory.

`PP_PREFIX` and `PP_DATA` can select safe absolute installation/state paths. The default account and port are fixed. Every future version needs a distinct version/manifest; do not mutate an installed version in place.

## Initial public baseline and normal maintenance

Copy only a verified, already-public unified JSON to a readable private input path under `/var/lib/private-publisher`. Use its expected checksum:

```sh
sudo sh /opt/private-publisher/current/scripts/operations.sh cli import pages /var/lib/private-publisher/public-input.json --sha256 EXPECTED_SHA256
sudo sh /opt/private-publisher/current/scripts/operations.sh cli catalog pages --kind article
sudo sh /opt/private-publisher/current/scripts/operations.sh cli status
```

`operations.sh cli` stops the managed UI, runs the command as the service account, then restarts it only if it was running. A process lock enforces one writer process per database. SQLite stays in `DELETE` journal mode with `synchronous=FULL`, without WAL or checkpoints. CLI maintenance and backup must be serialized with the UI rather than run concurrently.

Articles preserve stable `slug`, daily and experiment items preserve stable `id`. A leaf patch file contains explicit operations such as `[{"path":["title"],"value":"New title"}]`; unknown fields and public archive fields cannot be dropped by replacing a whole record. A revision is private until explicitly selected. Existing raw content is retained in 64 KiB chunks; export splices only selected item replacements or additions into the actual `posts`, `daily.reports[date]`, and `experiments` containers. Unchanged output is byte-exact; changed items preserve all unmodified JSON values. Daily `dates`, `columns`, `topicBars`, `issueMeta`, public revision archives and root metadata remain unchanged. New daily dates/metadata management is not implemented.

```sh
sudo sh /opt/private-publisher/current/scripts/operations.sh cli revise pages article EXISTING_SLUG /var/lib/private-publisher/patch.json
sudo sh /opt/private-publisher/current/scripts/operations.sh cli request --revision REVISION_ID --site pages
sudo sh /opt/private-publisher/current/scripts/operations.sh cli export REQUEST_ID pages /var/lib/private-publisher/new-public-snapshot.json
```

Inspect the snapshot and give it to the existing publishing route. Export does not publish. Manual results must name the exact exported hash. Public changes since a private revision cause conflict detection; request baselines and selected versions stay pinned.

## Backup, restore and rollback

```sh
sudo sh /opt/private-publisher/current/scripts/operations.sh backup backup-YYYYMMDD.zip
sudo sh /opt/private-publisher/current/scripts/operations.sh restore backup-YYYYMMDD.zip
sudo sh /opt/private-publisher/current/scripts/operations.sh stop
sudo sh /opt/private-publisher/current/scripts/operations.sh start
sudo sh /opt/private-publisher/current/scripts/rollback.sh PREVIOUS_INSTALLED_VERSION
```

Backup filenames resolve only under the private state's `backups/` directory. Restore checks the archive digest, database integrity and foreign keys before switching the database. It retains `before-restore-TIMESTAMP.sqlite3` for recovery; timestamps must be unique between repeated restores. Recovery copies must remain private. Code rollback does not roll back data or schemas. Only roll back to a version proven compatible with the database, or restore its corresponding backup while stopped. This prototype has no schema migrations yet. Stop is the immediate reversible shutdown; it leaves code and private data intact.

## Tests and limits

The local project contains unit/HTTP tests, full real unified JSON roundtrip and merge tests, and a separate bounded-memory benchmark. Test fixtures and evidence are excluded from this code-only bundle. Actual deployment compatibility/resource evidence belongs in the operator's deployment report. Do not infer the server's memory margin from small synthetic tests.

Not implemented: application login/authorization, rendered website preview, remote publish/verification/retry, credentials, encrypted/off-site/scheduled backups, attachments, new daily metadata/date workflows, deletion/withdrawal, concurrent editor conflict UX, schema migrations or storage retention quotas. Publishing history status is manually recorded. Server SSH host key policy belongs to the operator and must stay strict.
