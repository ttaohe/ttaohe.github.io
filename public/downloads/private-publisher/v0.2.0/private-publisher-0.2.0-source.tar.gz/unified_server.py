"""Unified-content loopback UI; no credentials or automatic network publication."""
import argparse
from http.server import HTTPServer
from urllib.parse import parse_qs, urlsplit, urlencode
from server import Handler, escape
from publisher import encode
from unified import UnifiedStore, strict_json


class UnifiedHandler(Handler):
    def sites_form(self):
        body = ""
        for row in self.server.store.db.execute("SELECT DISTINCT site FROM u_baselines ORDER BY site"):
            body += "<label><input type='checkbox' name='site' value='%s'>%s</label> " % (escape(row[0]), escape(row[0]))
        return body

    def do_GET(self):
        if not self.allowed_host(): self.page("Host rejected", 403); return
        store = self.server.store
        url = urlsplit(self.path)
        query = parse_qs(url.query, keep_blank_values=True)
        try:
            if url.path == "/health":
                self.page("healthy · loopback prototype")
            elif url.path == "/":
                body = "<p><a href='/catalog'>公开基线目录</a> · <a href='/new'>新建私有条目</a></p>"
                body += "<h2>私有版本</h2><p>默认不选中；公开基线只有在明确选中版本后才会变更。</p><form method='post' action='/request'>"
                for row in store.private_catalog():
                    body += "<p><label><input type='checkbox' name='revision' value='%s'>%s %s %s</label> <a href='/revision?id=%s'>预览 / 修改 / 历史</a></p>" % (row["revision_id"], escape(row["kind"]), escape(row["day"]), escape(row["key"]), row["revision_id"])
                body += self.sites_form() + "<button>记录发布请求（不自动发布）</button></form><h2>每站状态</h2><ul>"
                for row in store.statuses_unified():
                    body += "<li>请求 %s · %s · %s · %s</li>" % (row["request_id"], escape(row["site"]), escape(row["status"]), escape(row["detail"] or ""))
                self.page(body + "</ul><p>导出、备份、恢复及人工发布结果使用 CLI。导出成功不代表站点发布成功。</p>")
            elif url.path == "/catalog":
                sites = [row[0] for row in store.db.execute("SELECT DISTINCT site FROM u_baselines ORDER BY site")]
                if not sites: self.page("尚未导入公开基线，请通过 CLI 导入。"); return
                site = query.get("site", [sites[0]])[0]
                offset = max(0, int(query.get("offset", [0])[0]))
                kind = query.get("kind", [None])[0] or None
                day = query.get("day", [None])[0] or None
                baseline = store.baseline(site)["id"]
                body = "<p><a href='/'>返回</a></p><h2>公开条目（编辑只产生私有版本）</h2><form method='get'><input name='site' value='%s'><select name='kind'><option value=''>全部</option><option>article</option><option>daily</option><option>experiment</option></select><input name='day' placeholder='日报日期，如 10.09'><button>筛选</button></form><ul>" % escape(site)
                for row in store.catalog(baseline, kind, day, offset=offset):
                    link = urlencode({"site": site, "kind": row["kind"], "day": row["day"], "key": row["key"]})
                    body += "<li><a href='/entry?%s'>%s · %s · %s</a></li>" % (escape(link), escape(row["kind"]), escape(row["day"]), escape(row["title"]))
                link = urlencode({"site": site, "offset": offset + 50, "kind": kind or "", "day": day or ""})
                self.page(body + "</ul><a href='/catalog?%s'>下一页</a>" % escape(link))
            elif url.path in {"/entry", "/revision"}:
                body = "<p><a href='/'>返回</a></p><p>纯文本数据预览；不是网站渲染预览。历史归档和未知字段只读保留。</p>"
                if url.path == "/entry":
                    site, kind, key, day = [query[name][0] for name in ["site", "kind", "key", "day"]]
                    baseline = store.baseline(site)["id"]
                    _, payload = store.item(baseline, kind, key, day)
                    hidden = {"baseline": baseline, "kind": kind, "key": key, "day": day}
                else:
                    revision_id = int(query["id"][0]); revision = store.revision_unified(revision_id)
                    payload = revision["payload"]; hidden = {"revision": revision_id}
                    body += "<h3>版本历史</h3><ul>"
                    for row in store.history_unified(revision_id):
                        body += "<li><a href='/revision?id=%s'>版本 %s · %s</a></li>" % (row["id"], row["id"], escape(row["created"]))
                    body += "</ul><form method='post' action='/rollback'><input type='hidden' name='revision' value='%s'><button>复制此版本为新当前版本</button></form>" % revision_id
                    body += "<form method='post' action='/request'><input type='hidden' name='revision' value='%s'>%s<button>明确选择此版本创建请求</button></form>" % (revision_id, self.sites_form())
                body += "<h2>%s</h2><pre>%s</pre><h3>修改字段，保存私有版本</h3><p>JSON 操作示例：[{&quot;path&quot;:[&quot;title&quot;],&quot;value&quot;:&quot;新标题&quot;}]。只允许既有字段的标量叶节点；slug/id 和历史归档受保护。</p><form method='post' action='/revise'>" % (escape(payload["title"]), escape(encode(payload)))
                for name, value in hidden.items(): body += "<input type='hidden' name='%s' value='%s'>" % (name, escape(value))
                body += "<textarea name='operations' rows='6' cols='90' required></textarea><br><button>保存私有版本</button></form>"
                self.page(body)
            elif url.path == "/new":
                self.page("<p><a href='/'>返回</a></p><h2>新建私有条目</h2><p>填写符合原站类型的完整 JSON 对象。新日报只能选已有日期容器；新日期及期刊元数据管理尚未实现。</p><form method='post' action='/new'><select name='kind'><option>article</option><option>daily</option><option>experiment</option></select><input name='day' placeholder='日报已有日期，如 10.09'><br><textarea name='record' rows='18' cols='90' required></textarea><br><button>仅保存私有草稿</button></form>")
            else: self.page("Not found", 404)
        except (ValueError, KeyError, IndexError, TypeError):
            self.page("Invalid request", 400)

    def do_POST(self):
        if not self.allowed_host() or self.headers.get("Origin") != "http://" + self.headers.get("Host", ""):
            self.page("Origin rejected", 403); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 512 * 1024 or self.headers.get("Transfer-Encoding"): raise ValueError("request too large")
            if self.headers.get("Content-Type", "").split(";")[0] != "application/x-www-form-urlencoded": raise ValueError("invalid content type")
            raw = self.rfile.read(length)
            if len(raw) != length: raise ValueError("incomplete request")
            form = parse_qs(raw.decode(), keep_blank_values=True, max_num_fields=1024)
            store = self.server.store
            if self.path == "/revise":
                operations = strict_json(form["operations"][0])
                if "revision" in form: store.revise_private(int(form["revision"][0]), operations)
                else: store.revise(int(form["baseline"][0]), form["kind"][0], form["key"][0], operations, form["day"][0])
            elif self.path == "/new": store.new_private(form["kind"][0], strict_json(form["record"][0]), form["day"][0])
            elif self.path == "/rollback": store.rollback_unified(int(form["revision"][0]))
            elif self.path == "/request":
                revisions = [int(value) for value in form.get("revision", [])]
                if not revisions: raise ValueError("explicit selection required in browser")
                store.request_unified(revisions, form.get("site", []))
            else: self.page("Not found", 404); return
            self.send_response(303); self.send_header("Location", "/"); self.send_header("Content-Length", "0"); self.end_headers()
        except (ValueError, KeyError, IndexError, TypeError, UnicodeError):
            self.page("Invalid input or public baseline conflict; no publication occurred", 400)


def make_server(database, port=8080):
    server = HTTPServer(("127.0.0.1", port), UnifiedHandler)
    server.store = UnifiedStore(database)
    return server


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="data/private.sqlite3"); parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args(); server = make_server(args.db, args.port)
    print("Unified prototype listening on http://127.0.0.1:%s" % server.server_port, flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); server.store.close()
