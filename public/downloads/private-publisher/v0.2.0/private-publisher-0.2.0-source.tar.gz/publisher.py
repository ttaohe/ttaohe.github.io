"""Small private publishing prototype. Python 3.10, standard library only."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone

KINDS = {"article", "daily", "experiment"}
EXTENSION = "private_backend_public"
MAX_JSON = 8 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def read_json(path):
    path = Path(path)
    if path.stat().st_size > MAX_JSON:
        raise ValueError("JSON exceeds 8 MiB prototype limit")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def reject(value):
        raise ValueError("non-finite JSON number")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                      parse_constant=reject)


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = str(self.path) + ".lock"
        self.lock = os.fdopen(os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600), "a+b")
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.lock.close()
            raise ValueError("database in use: stop the UI before CLI maintenance")
        # New private files only: never chmod existing user directories.
        if not self.path.exists():
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        self.db = sqlite3.connect(str(self.path))
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA cache_size=-2048")
        if self.db.execute("PRAGMA journal_mode").fetchone()[0] != "delete":
            self.db.close(); self.lock.close()
            raise ValueError("only DELETE journal mode is supported; do not open WAL databases")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
          id INTEGER PRIMARY KEY, kind TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS revisions (
          id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL REFERENCES documents(id),
          title TEXT NOT NULL, body TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS baselines (
          id INTEGER PRIMARY KEY, site TEXT NOT NULL, payload TEXT NOT NULL,
          sha256 TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS requests (
          id INTEGER PRIMARY KEY, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS selections (
          request_id INTEGER REFERENCES requests(id),
          revision_id INTEGER REFERENCES revisions(id),
          PRIMARY KEY(request_id, revision_id));
        CREATE TABLE IF NOT EXISTS targets (
          request_id INTEGER REFERENCES requests(id), site TEXT NOT NULL,
          baseline_id INTEGER REFERENCES baselines(id),
          PRIMARY KEY(request_id, site));
        CREATE TABLE IF NOT EXISTS results (
          id INTEGER PRIMARY KEY, request_id INTEGER NOT NULL, site TEXT NOT NULL,
          status TEXT NOT NULL, detail TEXT NOT NULL, digest TEXT,
          created TEXT NOT NULL,
          FOREIGN KEY(request_id, site) REFERENCES targets(request_id, site));
        """)
        self.db.commit()

    def close(self):
        self.db.close()
        self.lock.close()

    def save(self, kind, title, body, document_id=None):
        if kind not in KINDS or not title.strip():
            raise ValueError("valid kind and nonempty title required")
        if len(title.encode()) > 4096 or len(body.encode()) > 256 * 1024:
            raise ValueError("document exceeds prototype size limit")
        with self.db:
            if document_id is None:
                document_id = self.db.execute(
                    "INSERT INTO documents(kind,created) VALUES (?,?)", (kind, now())).lastrowid
            elif not self.db.execute("SELECT 1 FROM documents WHERE id=? AND kind=?",
                                     (document_id, kind)).fetchone():
                raise ValueError("document missing or kind mismatch")
            revision = self.db.execute(
                "INSERT INTO revisions(document_id,title,body,created) VALUES (?,?,?,?)",
                (document_id, title, body, now())).lastrowid
        return document_id, revision

    def documents(self):
        return [dict(row) for row in self.db.execute("""
          SELECT d.id,d.kind,r.id AS revision_id,r.title,r.created
          FROM documents d JOIN revisions r ON r.document_id=d.id
          WHERE r.id=(SELECT max(id) FROM revisions WHERE document_id=d.id)
          ORDER BY d.id DESC""")]

    def revision(self, revision_id):
        row = self.db.execute("""SELECT r.*,d.kind FROM revisions r
          JOIN documents d ON d.id=r.document_id WHERE r.id=?""", (revision_id,)).fetchone()
        if row is None:
            raise ValueError("revision missing")
        return dict(row)

    def history(self, document_id):
        return [dict(row) for row in self.db.execute(
            "SELECT id,title,created FROM revisions WHERE document_id=? ORDER BY id DESC",
            (document_id,))]

    def rollback(self, revision_id):
        old = self.revision(revision_id)
        return self.save(old["kind"], old["title"], old["body"], old["document_id"])

    def import_public(self, site, payload):
        if not site.strip() or len(site) > 128:
            raise ValueError("invalid site name")
        if not isinstance(payload, dict) or EXTENSION in payload:
            raise ValueError("public baseline must be an object without reserved extension")
        serialized = encode(payload)
        if len(serialized.encode()) > MAX_JSON:
            raise ValueError("baseline exceeds size limit")
        with self.db:
            return self.db.execute(
                "INSERT INTO baselines(site,payload,sha256,created) VALUES (?,?,?,?)",
                (site, serialized, hashlib.sha256(serialized.encode()).hexdigest(), now())).lastrowid

    def request(self, revision_ids, sites):
        if not revision_ids or not sites or len(set(sites)) != len(sites):
            raise ValueError("explicit revisions and unique sites required")
        revisions = [self.revision(value) for value in revision_ids]
        if len({row["document_id"] for row in revisions}) != len(revisions):
            raise ValueError("select exactly one revision per document")
        baseline_ids = []
        for site in sites:
            row = self.db.execute("SELECT id FROM baselines WHERE site=? ORDER BY id DESC LIMIT 1",
                                  (site,)).fetchone()
            if row is None:
                raise ValueError("public baseline required for every site")
            baseline_ids.append((site, row["id"]))
        with self.db:
            request_id = self.db.execute("INSERT INTO requests(created) VALUES (?)", (now(),)).lastrowid
            self.db.executemany("INSERT INTO selections VALUES (?,?)",
                                [(request_id, value) for value in revision_ids])
            self.db.executemany("INSERT INTO targets VALUES (?,?,?)",
                                [(request_id, site, baseline) for site, baseline in baseline_ids])
        return request_id

    def snapshot(self, request_id, site):
        row = self.db.execute("""SELECT b.payload FROM targets t JOIN baselines b ON b.id=t.baseline_id
          WHERE t.request_id=? AND t.site=?""", (request_id, site)).fetchone()
        if row is None:
            raise ValueError("request target missing")
        baseline = json.loads(row["payload"])
        public = json.loads(row["payload"])
        selected = [self.revision(row[0]) for row in self.db.execute(
            "SELECT revision_id FROM selections WHERE request_id=? ORDER BY revision_id", (request_id,))]
        public[EXTENSION] = {"schema_version": 1, "request_id": request_id,
                             "items": selected}
        # Validate lossless baseline retention and exact pinned revision selection.
        if {key: value for key, value in public.items() if key != EXTENSION} != baseline:
            raise ValueError("baseline retention validation failed")
        if [row["id"] for row in selected] != [row[0] for row in self.db.execute(
            "SELECT revision_id FROM selections WHERE request_id=? ORDER BY revision_id", (request_id,))]:
            raise ValueError("revision selection validation failed")
        return public

    def export(self, request_id, site, destination):
        data = (encode(self.snapshot(request_id, site)) + "\n").encode()
        digest = hashlib.sha256(data).hexdigest()
        private_write(destination, data)
        self.result(request_id, site, "exported", "Validated snapshot exported locally", digest)
        return digest

    def result(self, request_id, site, status, detail, digest=None):
        if status not in {"exported", "published", "failed"}:
            raise ValueError("invalid status")
        if status != "exported":
            export = self.db.execute("""SELECT digest FROM results WHERE request_id=? AND site=?
              AND status='exported' ORDER BY id DESC LIMIT 1""", (request_id, site)).fetchone()
            if export is None or digest != export["digest"]:
                raise ValueError("manual result must reference latest exported digest")
        with self.db:
            self.db.execute("INSERT INTO results(request_id,site,status,detail,digest,created) VALUES (?,?,?,?,?,?)",
                            (request_id, site, status, detail[:4096], digest, now()))

    def requests(self):
        return [dict(row) for row in self.db.execute("""
          SELECT t.request_id,t.site,COALESCE(r.status,'pending') AS status,r.digest,r.detail
          FROM targets t LEFT JOIN results r ON r.id=(SELECT max(id) FROM results
            WHERE request_id=t.request_id AND site=t.site)
          ORDER BY t.request_id DESC,t.site""")]

    def backup(self, destination):
        with tempfile.TemporaryDirectory() as directory:
            copy = Path(directory) / "database.sqlite3"
            connection = sqlite3.connect(str(copy))
            try:
                self.db.backup(connection, pages=64)
                if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("backup integrity failed")
            finally:
                connection.close()
            if copy.stat().st_size > 256 * 1024 * 1024:
                raise ValueError("backup exceeds 256 MiB prototype limit")
            manifest = {"format": 1, "created": now(),
                        "sha256": file_digest(copy)}
            destination = Path(destination)
            # Exclusive creation prevents silently replacing a backup.
            with open_private(destination) as handle:
                with zipfile.ZipFile(handle, "w", compression=zipfile.ZIP_STORED) as archive:
                    archive.write(copy, "database.sqlite3")
                    archive.writestr("manifest.json", encode(manifest))
        return manifest


def file_digest(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def open_private(path):
    return os.fdopen(os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb")


def private_write(path, data):
    with open_private(path) as handle:
        handle.write(data)


def restore(archive_path, destination):
    destination = Path(destination)
    if destination.exists():
        raise ValueError("restore requires a new destination")
    with zipfile.ZipFile(archive_path) as archive:
        if sorted(archive.namelist()) != ["database.sqlite3", "manifest.json"]:
            raise ValueError("unexpected backup members")
        if archive.getinfo("manifest.json").file_size > 8192:
            raise ValueError("manifest too large")
        if archive.getinfo("database.sqlite3").file_size > 256 * 1024 * 1024:
            raise ValueError("backup exceeds 256 MiB prototype limit")
        manifest = json.loads(archive.read("manifest.json"))
        if manifest.get("format") != 1:
            raise ValueError("unsupported backup format")
        with tempfile.TemporaryDirectory(dir=str(destination.parent)) as directory:
            candidate = Path(directory) / "restored.sqlite3"
            with archive.open("database.sqlite3") as source, open_private(candidate) as target:
                for chunk in iter(lambda: source.read(65536), b""):
                    target.write(chunk)
            if file_digest(candidate) != manifest["sha256"]:
                raise ValueError("backup hash mismatch")
            db = sqlite3.connect(str(candidate))
            try:
                if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise ValueError("database integrity failed")
                if db.execute("PRAGMA foreign_key_check").fetchall():
                    raise ValueError("database references invalid")
                required = {"documents", "revisions", "baselines", "requests", "selections", "targets", "results"}
                found = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not required.issubset(found):
                    raise ValueError("backup schema missing")
            finally:
                db.close()
            # Link is exclusive: never overwrite a live database, even after a race.
            os.link(candidate, destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="data/private.sqlite3")
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("list")
    save = sub.add_parser("save")
    save.add_argument("kind", choices=sorted(KINDS)); save.add_argument("title")
    save.add_argument("body_file"); save.add_argument("--document", type=int)
    history = sub.add_parser("history"); history.add_argument("document", type=int)
    rollback = sub.add_parser("rollback"); rollback.add_argument("revision", type=int)
    baseline = sub.add_parser("import-public")
    baseline.add_argument("site"); baseline.add_argument("json_file")
    request = sub.add_parser("request")
    request.add_argument("--revision", type=int, action="append", required=True)
    request.add_argument("--site", action="append", required=True)
    export = sub.add_parser("export")
    export.add_argument("request", type=int); export.add_argument("site"); export.add_argument("output")
    sub.add_parser("status")
    result = sub.add_parser("record-result")
    result.add_argument("request", type=int); result.add_argument("site")
    result.add_argument("status", choices=["published", "failed"])
    result.add_argument("digest"); result.add_argument("detail")
    backup = sub.add_parser("backup"); backup.add_argument("output")
    recovery = sub.add_parser("restore"); recovery.add_argument("archive"); recovery.add_argument("output")
    args = parser.parse_args()
    if args.action == "restore":
        restore(args.archive, args.output)
        print("restored to new database")
        return
    store = Store(args.db)
    try:
        if args.action == "list": value = store.documents()
        elif args.action == "save":
            body = Path(args.body_file)
            if body.stat().st_size > 256 * 1024: raise ValueError("body too large")
            value = store.save(args.kind, args.title, body.read_text(encoding="utf-8"), args.document)
        elif args.action == "history": value = store.history(args.document)
        elif args.action == "rollback": value = store.rollback(args.revision)
        elif args.action == "import-public": value = store.import_public(args.site, read_json(args.json_file))
        elif args.action == "request": value = store.request(args.revision, args.site)
        elif args.action == "export": value = store.export(args.request, args.site, args.output)
        elif args.action == "status": value = store.requests()
        elif args.action == "record-result": value = store.result(args.request, args.site, args.status, args.detail, args.digest)
        elif args.action == "backup": value = store.backup(args.output)
        print(encode(value))
    finally:
        store.close()


if __name__ == "__main__":
    main()
