"""Lossless, bounded-memory adapter for the public site's unified content.json."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit
from publisher import Store, encode, now, open_private, restore

CHUNK = 65536
MAX_SOURCE = 64 * 1024 * 1024
MAX_ITEM = 4 * 1024 * 1024


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result: raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def reject(_): raise ValueError("non-finite JSON")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=reject)


def semantic_digest(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def locator(path):
    if len(path) == 2 and path[0] in {"posts", "experiments"} and isinstance(path[1], int):
        return ("article" if path[0] == "posts" else "experiment", "")
    if len(path) == 4 and path[:2] == ("daily", "reports") and isinstance(path[3], int):
        return "daily", path[2]


def container(path):
    if path == ("posts",): return "article", ""
    if path == ("experiments",): return "experiment", ""
    if len(path) == 3 and path[:2] == ("daily", "reports"): return "daily", path[2]


class Scanner:
    """Validate JSON grammar without retaining the complete document in RAM."""
    def __init__(self, source, visit):
        self.source = source
        self.visit = visit
        self.buffer = b""
        self.index = 0
        self.position = 0

    def peek(self):
        if self.index == len(self.buffer):
            self.buffer = self.source.read(CHUNK)
            self.index = 0
        return self.buffer[self.index] if self.buffer else None

    def take(self):
        value = self.peek()
        if value is None: raise ValueError("unexpected end of JSON")
        self.index += 1
        self.position += 1
        return value

    def spaces(self):
        while self.peek() in (9, 10, 13, 32): self.take()

    def expect(self, value):
        if self.take() != value: raise ValueError("invalid JSON structure")

    def string(self):
        token = bytearray([self.take()])
        escaped = False
        while True:
            char = self.take()
            token.append(char)
            if len(token) > MAX_ITEM: raise ValueError("JSON string exceeds limit")
            if char == 34 and not escaped: break
            if char < 32: raise ValueError("control character in JSON string")
            escaped = char == 92 and not escaped
        return strict_json(bytes(token))

    def value(self, path=(), depth=0):
        if depth > 100: raise ValueError("JSON nesting exceeds limit")
        self.spaces()
        start = self.position
        char = self.peek()
        count = None
        if char == 123:
            self.take(); self.spaces()
            keys = set()
            if self.peek() != 125:
                while True:
                    if self.peek() != 34: raise ValueError("object key must be string")
                    key = self.string()
                    if key in keys: raise ValueError("duplicate JSON key")
                    keys.add(key)
                    self.spaces(); self.expect(58)
                    self.value(path + (key,), depth + 1)
                    self.spaces()
                    if self.peek() == 125: break
                    self.expect(44); self.spaces()
            self.expect(125)
        elif char == 91:
            self.take(); self.spaces(); count = 0
            if self.peek() != 93:
                while True:
                    self.value(path + (count,), depth + 1)
                    count += 1
                    self.spaces()
                    if self.peek() == 93: break
                    self.expect(44)
            self.expect(93)
        elif char == 34:
            self.string()
        else:
            token = bytearray()
            while self.peek() is not None and self.peek() not in (9, 10, 13, 32, 44, 93, 125):
                token.append(self.take())
                if len(token) > 128: raise ValueError("invalid JSON scalar")
            if not token: raise ValueError("missing JSON value")
            scalar = strict_json(bytes(token))
            if isinstance(scalar, float) and not math.isfinite(scalar):
                raise ValueError("non-finite number")
        self.visit(path, start, self.position, count, char)

    def scan(self):
        self.value()
        self.spaces()
        if self.peek() is not None: raise ValueError("trailing JSON data")


FIELDS = {
    "article": {"slug": str, "title": str, "subtitle": str, "date": str, "category": str,
                "tags": list, "kind": str, "summary": str, "outline": list, "sections": list,
                "takeaways": list, "openQuestions": list, "relatedSlugs": list,
                "sources": list, "disclosure": str},
    "daily": {"id": str, "rank": str, "category": str, "title": str, "summary": str,
              "why": str, "source": str, "sourceLabel": str, "reading": str,
              "signal": str, "columns": list},
    "experiment": {"id": str, "title": str, "hypothesis": str, "method": list,
                   "metrics": list, "falsifier": str, "related": list},
}


def validate_item(kind, item):
    if kind not in FIELDS or not isinstance(item, dict): raise ValueError("invalid item kind/object")
    for field, expected in FIELDS[kind].items():
        if not isinstance(item.get(field), expected): raise ValueError("invalid field: " + field)
    if not item["title"].strip(): raise ValueError("empty title")
    key = item["slug" if kind == "article" else "id"]
    if not key or len(key) > 512: raise ValueError("invalid stable identity")
    if kind == "article":
        if not re.fullmatch("[a-z0-9-]{1,100}", key): raise ValueError("invalid slug")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", item["date"]): raise ValueError("invalid article date")
        if len(item["outline"]) != len(item["sections"]) or not item["sections"]:
            raise ValueError("outline/sections mismatch")
        for section in item["sections"]:
            if not isinstance(section, dict) or not isinstance(section.get("heading"), str):
                raise ValueError("invalid section")
            if not isinstance(section.get("paragraphs"), list) or not all(isinstance(x, str) for x in section["paragraphs"]):
                raise ValueError("invalid paragraphs")
        for source in item["sources"]:
            if not isinstance(source, dict) or not isinstance(source.get("title"), str):
                raise ValueError("invalid source")
            https(source.get("url"))
    elif kind == "daily":
        if item["signal"] not in {"high", "medium"}: raise ValueError("invalid signal")
        https(item["source"])
    for field, expected in FIELDS[kind].items():
        if expected is list and field not in {"sections", "sources"}:
            if not all(isinstance(x, str) for x in item[field]): raise ValueError("invalid text list: " + field)
    return key


def https(value):
    if not isinstance(value, str) or urlsplit(value).scheme != "https" or not urlsplit(value).netloc:
        raise ValueError("HTTPS URL required")


def patch_item(kind, original, operations):
    # Leaf-only updates preserve unknown siblings and archive objects in full.
    item = strict_json(encode(original))
    if not isinstance(operations, list) or not operations or len(operations) > 128:
        raise ValueError("explicit leaf operations required")
    identity = "slug" if kind == "article" else "id"
    for operation in operations:
        path = operation.get("path") if isinstance(operation, dict) else None
        if not isinstance(path, list) or not path or path[0] not in FIELDS[kind] or path[0] == identity:
            raise ValueError("unknown or protected field")
        field = path[0]
        if FIELDS[kind][field] is str:
            allowed = len(path) == 1
        elif field == "sections":
            allowed = ((len(path) == 3 and path[2] in {"heading", "diagram", "code", "diagramUrl", "diagramDownloadUrl", "diagramCaption"})
                       or (len(path) == 4 and path[2] in {"paragraphs", "bullets"}))
        elif field == "sources":
            allowed = len(path) == 3 and path[2] in {"title", "url"}
        else:
            allowed = len(path) == 2
        if not allowed: raise ValueError("only defined editable leaves are allowed")
        parent = item
        for key in path[:-1]:
            if isinstance(parent, list) and (type(key) is not int or key < 0):
                raise ValueError("invalid list index")
            parent = parent[key]
        key = path[-1]
        if isinstance(parent, list) and (type(key) is not int or key < 0):
            raise ValueError("invalid list index")
        existing = parent[key]
        value = operation.get("value")
        if isinstance(existing, (dict, list)) or isinstance(value, (dict, list)) or type(existing) is not type(value):
            raise ValueError("only same-type existing scalar leaves may be revised")
        if isinstance(value, float) and not math.isfinite(value): raise ValueError("non-finite value")
        parent[key] = value
    validate_item(kind, item)
    return item


class UnifiedStore(Store):
    def __init__(self, path):
        super().__init__(path)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS u_baselines(id INTEGER PRIMARY KEY,site TEXT NOT NULL,sha256 TEXT NOT NULL,bytes INTEGER NOT NULL,created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS u_chunks(baseline_id INTEGER REFERENCES u_baselines(id),idx INTEGER,data BLOB NOT NULL,PRIMARY KEY(baseline_id,idx));
        CREATE TABLE IF NOT EXISTS u_items(baseline_id INTEGER REFERENCES u_baselines(id),kind TEXT,day TEXT,key TEXT,start INTEGER,end INTEGER,sha256 TEXT,title TEXT,PRIMARY KEY(baseline_id,kind,day,key));
        CREATE TABLE IF NOT EXISTS u_arrays(baseline_id INTEGER REFERENCES u_baselines(id),kind TEXT,day TEXT,end INTEGER,count INTEGER,PRIMARY KEY(baseline_id,kind,day));
        CREATE TABLE IF NOT EXISTS u_documents(id INTEGER PRIMARY KEY,kind TEXT,day TEXT,key TEXT,UNIQUE(kind,day,key));
        CREATE TABLE IF NOT EXISTS u_revisions(id INTEGER PRIMARY KEY,document_id INTEGER REFERENCES u_documents(id),base_sha256 TEXT,payload TEXT,created TEXT);
        CREATE TABLE IF NOT EXISTS u_requests(id INTEGER PRIMARY KEY,created TEXT);
        CREATE TABLE IF NOT EXISTS u_selections(request_id INTEGER REFERENCES u_requests(id),revision_id INTEGER REFERENCES u_revisions(id),PRIMARY KEY(request_id,revision_id));
        CREATE TABLE IF NOT EXISTS u_targets(request_id INTEGER REFERENCES u_requests(id),site TEXT,baseline_id INTEGER REFERENCES u_baselines(id),PRIMARY KEY(request_id,site));
        CREATE TABLE IF NOT EXISTS u_results(id INTEGER PRIMARY KEY,request_id INTEGER,site TEXT,status TEXT,digest TEXT,detail TEXT,created TEXT,FOREIGN KEY(request_id,site) REFERENCES u_targets(request_id,site));
        """)
        self.db.commit()

    def import_unified(self, site, source, expected_sha256=None):
        if not site.strip() or len(site) > 128: raise ValueError("invalid site")
        source = Path(source)
        size = source.stat().st_size
        if size > MAX_SOURCE: raise ValueError("source exceeds 64 MiB limit")
        with self.db, source.open("rb") as stream, source.open("rb") as records:
            baseline = self.db.execute("INSERT INTO u_baselines(site,sha256,bytes,created) VALUES (?,?,?,?)",
                                       (site, "pending", size, now())).lastrowid
            digest = hashlib.sha256()
            for index, chunk in enumerate(iter(lambda: stream.read(CHUNK), b"")):
                digest.update(chunk)
                self.db.execute("INSERT INTO u_chunks VALUES (?,?,?)", (baseline, index, chunk))
            source_digest = digest.hexdigest()
            if expected_sha256 and source_digest != expected_sha256: raise ValueError("source SHA-256 mismatch")
            stream.seek(0)
            root_seen = {}
            def visit(path, start, end, count, char):
                if len(path) == 1: root_seen[path[0]] = char
                if path == ("schemaVersion",):
                    records.seek(start)
                    version = strict_json(records.read(end - start))
                    if type(version) is not int or version != 1: raise ValueError("schemaVersion must be 1")
                expected_type = {("daily",): 123, ("daily", "reports"): 123,
                                 ("daily", "dates"): 91, ("daily", "columns"): 91,
                                 ("daily", "topicBars"): 91, ("daily", "issueMeta"): 123,
                                 ("experiments",): 91}.get(path)
                if expected_type and char != expected_type: raise ValueError("invalid daily/experiment container")
                entry = locator(path)
                if entry:
                    kind, day = entry
                    if end - start > MAX_ITEM: raise ValueError("item exceeds 4 MiB limit")
                    records.seek(start)
                    item = strict_json(records.read(end - start))
                    key = validate_item(kind, item)
                    self.db.execute("INSERT INTO u_items VALUES (?,?,?,?,?,?,?,?)",
                                    (baseline, kind, day, key, start, end, semantic_digest(item), item["title"]))
                array = container(path)
                if array:
                    if count is None: raise ValueError("expected content array")
                    self.db.execute("INSERT INTO u_arrays VALUES (?,?,?,?,?)", (baseline, *array, end - 1, count))
            Scanner(stream, visit).scan()
            if root_seen.get("posts") != 91 or root_seen.get("schemaVersion") is None or root_seen.get("updatedAt") != 34:
                raise ValueError("unified root schema missing")
            # Reject source edits during scanning instead of persisting mismatched offsets.
            stream.seek(0); check = hashlib.sha256()
            for chunk in iter(lambda: stream.read(CHUNK), b""): check.update(chunk)
            if check.hexdigest() != source_digest or source.stat().st_size != size:
                raise ValueError("source changed during import")
            self.db.execute("UPDATE u_baselines SET sha256=? WHERE id=?", (source_digest, baseline))
        return baseline

    def baseline(self, site):
        row = self.db.execute("SELECT * FROM u_baselines WHERE site=? ORDER BY id DESC LIMIT 1", (site,)).fetchone()
        if row is None: raise ValueError("unified baseline missing")
        return dict(row)

    def catalog(self, baseline, kind=None, day=None, limit=50, offset=0):
        sql = "SELECT kind,day,key,title FROM u_items WHERE baseline_id=?"
        values = [baseline]
        for field, value in [("kind", kind), ("day", day)]:
            if value is not None: sql += " AND " + field + "=?"; values.append(value)
        sql += " ORDER BY kind,day,key LIMIT ? OFFSET ?"
        return [dict(row) for row in self.db.execute(sql, values + [min(limit, 100), max(offset, 0)])]

    def chunks(self, baseline, start, end):
        if start == end: return
        first, last = start // CHUNK, (end - 1) // CHUNK
        for row in self.db.execute("SELECT idx,data FROM u_chunks WHERE baseline_id=? AND idx BETWEEN ? AND ? ORDER BY idx",
                                   (baseline, first, last)):
            low = max(0, start - row["idx"] * CHUNK)
            high = min(CHUNK, end - row["idx"] * CHUNK)
            yield row["data"][low:high]

    def item(self, baseline, kind, key, day=""):
        row = self.db.execute("SELECT * FROM u_items WHERE baseline_id=? AND kind=? AND day=? AND key=?",
                              (baseline, kind, day, key)).fetchone()
        if row is None: raise ValueError("public item missing")
        return dict(row), strict_json(b"".join(self.chunks(baseline, row["start"], row["end"])))

    def _revision(self, kind, day, key, payload, base_sha):
        validate_item(kind, payload)
        text = encode(payload)
        if len(text.encode()) > MAX_ITEM: raise ValueError("item exceeds limit")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO u_documents(kind,day,key) VALUES (?,?,?)", (kind, day, key))
            document = self.db.execute("SELECT id FROM u_documents WHERE kind=? AND day=? AND key=?", (kind, day, key)).fetchone()[0]
            return self.db.execute("INSERT INTO u_revisions(document_id,base_sha256,payload,created) VALUES (?,?,?,?)",
                                   (document, base_sha, text, now())).lastrowid

    def revise(self, baseline, kind, key, operations, day=""):
        row, payload = self.item(baseline, kind, key, day)
        return self._revision(kind, day, key, patch_item(kind, payload, operations), row["sha256"])

    def revision_unified(self, revision):
        row = self.db.execute("SELECT r.*,d.kind,d.day,d.key FROM u_revisions r JOIN u_documents d ON d.id=r.document_id WHERE r.id=?",
                              (revision,)).fetchone()
        if row is None: raise ValueError("private revision missing")
        value = dict(row); value["payload"] = strict_json(value["payload"])
        return value

    def revise_private(self, revision, operations):
        row = self.revision_unified(revision)
        return self._revision(row["kind"], row["day"], row["key"], patch_item(row["kind"], row["payload"], operations), row["base_sha256"])

    def new_private(self, kind, payload, day=""):
        key = validate_item(kind, payload)
        if kind != "daily" and day: raise ValueError("day applies only to daily")
        if kind == "daily" and not re.fullmatch(r"\d{2}\.\d{2}", day): raise ValueError("existing daily date required")
        return self._revision(kind, day, key, payload, None)

    def rollback_unified(self, revision):
        row = self.revision_unified(revision)
        return self._revision(row["kind"], row["day"], row["key"], row["payload"], row["base_sha256"])

    def history_unified(self, revision):
        row = self.revision_unified(revision)
        return [dict(x) for x in self.db.execute("SELECT id,created FROM u_revisions WHERE document_id=? ORDER BY id DESC", (row["document_id"],))]

    def private_catalog(self):
        return [dict(x) for x in self.db.execute("""SELECT d.*,r.id AS revision_id,r.created FROM u_documents d JOIN u_revisions r ON r.document_id=d.id
          WHERE r.id=(SELECT max(id) FROM u_revisions WHERE document_id=d.id) ORDER BY d.id DESC""")]

    def _check(self, baseline, revision):
        row = self.db.execute("SELECT * FROM u_items WHERE baseline_id=? AND kind=? AND day=? AND key=?",
                              (baseline, revision["kind"], revision["day"], revision["key"])).fetchone()
        if revision["base_sha256"] is None:
            if row is not None: raise ValueError("new identity collides with public item")
            array = self.db.execute("SELECT * FROM u_arrays WHERE baseline_id=? AND kind=? AND day=?",
                                    (baseline, revision["kind"], revision["day"])).fetchone()
            if array is None: raise ValueError("new date/container needs explicit metadata workflow")
            return dict(array)
        if row is None or row["sha256"] != revision["base_sha256"]:
            raise ValueError("public item changed since private revision: conflict")
        return dict(row)

    def request_unified(self, revisions, sites):
        if not sites or len(set(sites)) != len(sites): raise ValueError("unique sites required")
        documents = set()
        targets = [(site, self.baseline(site)["id"]) for site in sites]
        for revision in revisions:
            row = self.revision_unified(revision)
            if row["document_id"] in documents: raise ValueError("one version per document required")
            documents.add(row["document_id"])
            for _, baseline in targets: self._check(baseline, row)
        with self.db:
            request = self.db.execute("INSERT INTO u_requests(created) VALUES (?)", (now(),)).lastrowid
            self.db.executemany("INSERT INTO u_selections VALUES (?,?)", [(request, revision) for revision in revisions])
            self.db.executemany("INSERT INTO u_targets VALUES (?,?,?)", [(request, site, baseline) for site, baseline in targets])
        return request

    def export_unified(self, request, site, destination):
        target = self.db.execute("SELECT b.* FROM u_targets t JOIN u_baselines b ON b.id=t.baseline_id WHERE t.request_id=? AND t.site=?", (request, site)).fetchone()
        if target is None: raise ValueError("request target missing")
        baseline = target["id"]
        # Sort only offsets/IDs, never retain all selected payloads.
        changes = []
        for selection in self.db.execute("SELECT revision_id FROM u_selections WHERE request_id=? ORDER BY revision_id", (request,)):
            revision = self.revision_unified(selection[0])
            item = self._check(baseline, revision)
            if revision["base_sha256"] is None:
                changes.append((item["end"], item["end"], selection[0], bool(item["count"])))
            else:
                changes.append((item["start"], item["end"], selection[0], None))
        changes.sort()
        digest = hashlib.sha256(); source_digest = hashlib.sha256()
        for chunk in self.chunks(baseline, 0, target["bytes"]): source_digest.update(chunk)
        if source_digest.hexdigest() != target["sha256"]: raise ValueError("stored baseline corrupt")
        written = set()
        destination = Path(destination)
        handle = open_private(destination)
        try:
            def write(data):
                handle.write(data); digest.update(data)
            position = 0
            for start, end, revision_id, nonempty in changes:
                if start < position: raise ValueError("overlapping edits")
                for chunk in self.chunks(baseline, position, start): write(chunk)
                revision = self.revision_unified(revision_id)
                if nonempty is not None:
                    if nonempty or start in written: write(b",")
                    written.add(start)
                write(encode(revision["payload"]).encode())
                position = end
            for chunk in self.chunks(baseline, position, target["bytes"]): write(chunk)
            handle.close()
            # Independent streaming reparse verifies grammar, uniqueness, shape and count.
            counts = {"article": 0, "daily": 0, "experiment": 0}
            identities = set()
            selected = {r[0] for r in self.db.execute("SELECT revision_id FROM u_selections WHERE request_id=?", (request,))}
            expected = {}
            for revision_id in selected:
                revision = self.revision_unified(revision_id)
                expected[(revision["kind"], revision["day"], revision["key"])] = semantic_digest(revision["payload"])
            found = set()
            with destination.open("rb") as stream, destination.open("rb") as records:
                def validate(path, start, end, count, char):
                    entry = locator(path)
                    if not entry: return
                    if end - start > MAX_ITEM: raise ValueError("export item exceeds limit")
                    records.seek(start); item = strict_json(records.read(end - start))
                    kind, day = entry; key = validate_item(kind, item)
                    identity = kind, day, key
                    if identity in identities: raise ValueError("duplicate exported identity")
                    identities.add(identity); counts[kind] += 1
                    if identity in expected:
                        if semantic_digest(item) != expected[identity]: raise ValueError("selected revision mismatch")
                        found.add(identity)
                Scanner(stream, validate).scan()
            if found != set(expected): raise ValueError("selected revision missing")
            with self.db:
                self.db.execute("INSERT INTO u_results(request_id,site,status,digest,detail,created) VALUES (?,?,?,?,?,?)",
                                (request, site, "exported", digest.hexdigest(), "Validated compatible snapshot; no network publication", now()))
            return {"sha256": digest.hexdigest(), "bytes": destination.stat().st_size, "counts": counts}
        except BaseException:
            handle.close(); destination.unlink(missing_ok=True)
            raise

    def statuses_unified(self):
        return [dict(row) for row in self.db.execute("""SELECT t.request_id,t.site,COALESCE(r.status,'pending') AS status,r.digest,r.detail
          FROM u_targets t LEFT JOIN u_results r ON r.id=(SELECT max(id) FROM u_results WHERE request_id=t.request_id AND site=t.site)
          ORDER BY t.request_id DESC,t.site""")]

    def result_unified(self, request, site, status, digest, detail):
        if status not in {"published", "failed"}: raise ValueError("invalid manual status")
        row = self.db.execute("SELECT digest FROM u_results WHERE request_id=? AND site=? AND status='exported' ORDER BY id DESC LIMIT 1", (request, site)).fetchone()
        if row is None or digest != row[0]: raise ValueError("manual result needs exact export digest")
        with self.db:
            self.db.execute("INSERT INTO u_results(request_id,site,status,digest,detail,created) VALUES (?,?,?,?,?,?)", (request, site, status, digest, detail[:4096], now()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="data/private.sqlite3")
    sub = parser.add_subparsers(dest="action", required=True)
    imp = sub.add_parser("import"); imp.add_argument("site"); imp.add_argument("source"); imp.add_argument("--sha256")
    catalog = sub.add_parser("catalog"); catalog.add_argument("site"); catalog.add_argument("--kind"); catalog.add_argument("--day"); catalog.add_argument("--offset", type=int, default=0)
    revise = sub.add_parser("revise"); revise.add_argument("site"); revise.add_argument("kind"); revise.add_argument("key"); revise.add_argument("operations"); revise.add_argument("--day", default="")
    private = sub.add_parser("revise-private"); private.add_argument("revision", type=int); private.add_argument("operations")
    new = sub.add_parser("new"); new.add_argument("kind"); new.add_argument("record"); new.add_argument("--day", default="")
    rollback = sub.add_parser("rollback"); rollback.add_argument("revision", type=int)
    history = sub.add_parser("history"); history.add_argument("revision", type=int)
    sub.add_parser("drafts")
    request = sub.add_parser("request"); request.add_argument("--revision", type=int, action="append", default=[]); request.add_argument("--site", action="append", required=True)
    export = sub.add_parser("export"); export.add_argument("request", type=int); export.add_argument("site"); export.add_argument("output")
    sub.add_parser("status")
    result = sub.add_parser("record-result"); result.add_argument("request", type=int); result.add_argument("site"); result.add_argument("status"); result.add_argument("digest"); result.add_argument("detail")
    backup = sub.add_parser("backup"); backup.add_argument("output")
    recovery = sub.add_parser("restore"); recovery.add_argument("archive"); recovery.add_argument("output")
    args = parser.parse_args()
    if args.action == "restore": restore(args.archive, args.output); print("restored to new path"); return
    store = UnifiedStore(args.db)
    def small_json(path):
        p = Path(path)
        if p.stat().st_size > MAX_ITEM: raise ValueError("input exceeds item limit")
        return strict_json(p.read_bytes())
    try:
        if args.action == "import": value = store.import_unified(args.site, args.source, args.sha256)
        elif args.action == "catalog": value = store.catalog(store.baseline(args.site)["id"], args.kind, args.day, offset=args.offset)
        elif args.action == "revise": value = store.revise(store.baseline(args.site)["id"], args.kind, args.key, small_json(args.operations), args.day)
        elif args.action == "revise-private": value = store.revise_private(args.revision, small_json(args.operations))
        elif args.action == "new": value = store.new_private(args.kind, small_json(args.record), args.day)
        elif args.action == "rollback": value = store.rollback_unified(args.revision)
        elif args.action == "history": value = store.history_unified(args.revision)
        elif args.action == "drafts": value = store.private_catalog()
        elif args.action == "request": value = store.request_unified(args.revision, args.site)
        elif args.action == "export": value = store.export_unified(args.request, args.site, args.output)
        elif args.action == "status": value = store.statuses_unified()
        elif args.action == "record-result": value = store.result_unified(args.request, args.site, args.status, args.digest, args.detail)
        elif args.action == "backup": value = store.backup(args.output)
        print(encode(value))
    finally: store.close()


if __name__ == "__main__": main()
