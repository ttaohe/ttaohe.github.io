# Private publisher 0.2.0 — complete source and test archive

This is a separate source/test archive. It does not change the deployed 0.2.0 runtime bundle. Runtime source files and PORTABLE.md are identical to that bundle. It adds all existing tests, both benchmarks, deterministic build scripts, and an opt-in public fixture downloader. No real fixture, database, private backup, logs, connection settings or credentials are included.

Requirements: existing Python 3.10+ standard library on macOS/Linux for tests; Linux/systemd for approved installation. No pip, Node, Docker or extra packages are needed. HTTP tests bind ephemeral 127.0.0.1 ports and close them. Some restricted environments need their normal single-run approval for loopback sockets.

## Offline review and tests

Verify the archive SHA-256 against the independent value delivered alongside it before unpacking. SOURCE_MANIFEST.json includes archive_kind=source-tests, version 0.2.0 and hashes of all files except itself. Review scripts before privileged execution.

From the extracted archive root:

```sh
python3 -m unittest discover -s tests -v
python3 benchmark.py
python3 build_release.py
sh scripts/install.sh --plan
python3 build_source_archive.py
```

The normal test command never downloads anything. Without fixtures/content.original.json the one full real-JSON compatibility test is explicitly skipped; all other tests are runnable offline. The fixture-downloader tests mock HTTP and never access the network. benchmark.py uses synthetic temporary data. Test/build artifacts are written only into temporary directories or local release/ and never to an external repository.

build_release.py reproduces the original runtime bundle under release/private-publisher-0.2.0.tar.gz, whose expected SHA-256 is:

```text
7e7edbe9996e5ec5958ac7fc7a350498a2706eeb9202751645d53f56c4448603
```

build_source_archive.py reproduces this separate source/test archive; compare its output hash with the delivered source archive hash. Neither build script downloads dependencies or publishes anything.

## Optional real public fixture test — explicit network step

Only if you choose to fetch the fixed public sample, run:

```sh
python3 scripts/download_fixture.py
python3 -m unittest discover -s tests -p test_unified.py -v
python3 benchmark_unified.py
```

The downloader is read-only against one HTTPS public URL at fixed commit 6fdfa533781642a69e8931df6eafaa10250e5938, lib/blog/content.json. It checks exact size 12972715 and SHA-256 ee516cbf6ad9da28e59c87724e57054e8efbfc1e80d12ea539a03f67bfc9d450 before committing the local file, refuses corrupted existing files, and does not execute repository code or workflows. It stores no credentials and does not use Drive. An already verified fixture is reused without a new request. Network/auth/permission failures should be reported rather than bypassed.

The real compatibility test verifies exact no-change roundtrip, single-entry edits retaining all unknown fields/history/daily metadata, unselected-draft isolation, old version selection, conflicts, pinned requests and complete backup restoration. benchmark_unified.py measures the production adapter separately from whole-document equality assertions. The fixture is excluded every time the source archive is built, even if downloaded locally.

## Runtime and limits

Use unified_server.py / unified.py for the actual unified JSON adapter. The earlier generic server.py is retained for its prototype tests; it is not the compatible site export interface. See PORTABLE.md for installation, health, private backup/recovery, code rollback and opt-in fixed-code fetching. Code retrieval, private-state recovery and user credential configuration remain separate.

Application authentication, automatic remote publication/verification, encrypted off-site backups and a public release URL are not implemented. This archive is source evidence for a loopback-only single-user prototype, not a claim that those features are complete. No server modification is performed by building/testing it.
