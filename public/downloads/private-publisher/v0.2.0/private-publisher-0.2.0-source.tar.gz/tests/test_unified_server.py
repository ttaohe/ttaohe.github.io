import queue
import tempfile
import threading
from pathlib import Path
import unittest
from http.client import HTTPConnection
from urllib.parse import urlencode
from unified_server import make_server


class UnifiedHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); ready = queue.Queue()
        def run():
            try:
                server = make_server(Path(self.temp.name) / 'db.sqlite3', 0)
                ready.put(server)
                try: server.serve_forever(poll_interval=0.05)
                finally: server.server_close(); server.store.close()
            except Exception as error: ready.put(error)
        self.thread = threading.Thread(target=run); self.thread.start()
        self.server = ready.get(timeout=5)
        if isinstance(self.server, Exception): raise self.server
        self.port = self.server.server_port

    def tearDown(self):
        self.server.shutdown(); self.thread.join(timeout=5); self.temp.cleanup()

    def call(self, method, path, data=None, headers=None):
        c=HTTPConnection('127.0.0.1',self.port,timeout=5)
        try:
            c.request(method,path,data,headers or {}); r=c.getresponse()
            return r.status, r.read().decode()
        finally: c.close()

    def test_health_csrf_path_traversal_and_unselected_default(self):
        self.assertEqual(self.server.server_address[0], '127.0.0.1')
        self.assertEqual(self.call('GET','/health')[0],200)
        self.assertEqual(self.call('GET','/health',headers={'Host':'evil.example'})[0],403)
        self.assertEqual(self.call('GET','/../../etc/passwd')[0],404)
        self.assertEqual(self.call('POST','/request',urlencode({'site':'pages'}))[0],403)
        headers={'Content-Type':'application/x-www-form-urlencoded','Origin':'http://127.0.0.1:%s'%self.port}
        self.assertEqual(self.call('POST','/request',urlencode({'site':'pages'}),headers)[0],400)
        record={'id':'NEW-PRIVATE','title':'<script>secret</script>','hypothesis':'hypothesis','method':[],'metrics':[],'falsifier':'result','related':[]}
        import json
        self.assertEqual(self.call('POST','/new',urlencode({'kind':'experiment','day':'','record':json.dumps(record)}),headers)[0],303)
        self.assertNotIn(' checked',self.call('GET','/')[1])
        preview=self.call('GET','/revision?id=1')[1]
        self.assertNotIn('<script>',preview); self.assertIn('&lt;script&gt;',preview)


if __name__=='__main__': unittest.main()
