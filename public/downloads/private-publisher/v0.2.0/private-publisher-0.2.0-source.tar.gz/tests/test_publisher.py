import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from publisher import Store, EXTENSION, restore, read_json


class PublishingTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.store = Store(self.root / "private.sqlite3")

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def test_unselected_drafts_excluded_baseline_history_retained_and_revisions_pinned(self):
        baseline = {"history": [{"unknown": [1, "旧文章", None]}], "future": {"field": True}}
        self.store.import_public("pages", baseline)
        self.store.import_public("second", {"old": "retain"})
        doc, revision = self.store.save("article", "公开标题", "公开内容")
        self.store.save("daily", "PRIVATE_SENTINEL", "PRIVATE_BODY_SENTINEL")
        request = self.store.request([revision], ["pages", "second"])
        self.store.save("article", "later private edit", "private later body", doc)
        self.store.import_public("pages", {"replacement": "must not affect pinned baseline"})
        snapshot = self.store.snapshot(request, "pages")
        self.assertEqual({k: v for k, v in snapshot.items() if k != EXTENSION}, baseline)
        self.assertEqual(snapshot[EXTENSION]["items"][0]["body"], "公开内容")
        output = self.root / "public.json"
        digest = self.store.export(request, "pages", output)
        content = output.read_text()
        self.assertNotIn("PRIVATE_", content)
        self.assertNotIn("later private", content)
        self.assertEqual(hashlib.sha256(output.read_bytes()).hexdigest(), digest)
        self.assertEqual({r["site"]: r["status"] for r in self.store.requests()},
                         {"pages": "exported", "second": "pending"})
        with self.assertRaises(ValueError):
            self.store.result(request, "pages", "published", "manual", "wrong digest")
        self.store.result(request, "pages", "published", "Manual confirmation", digest)
        states = {r["site"]: r["status"] for r in self.store.requests()}
        self.assertEqual(states, {"pages": "published", "second": "pending"})

    def test_backup_recovers_all_private_records_and_history(self):
        self.store.import_public("pages", {"history": ["all old data"]})
        doc, original = self.store.save("experiment", "version 1", "private content")
        self.store.save("experiment", "version 2", "new content", doc)
        self.store.rollback(original)
        request = self.store.request([original], ["pages"])
        self.store.export(request, "pages", self.root / "snapshot.json")
        archive = self.root / "backup.zip"
        self.store.backup(archive)
        recovered = self.root / "recovered.sqlite3"
        restore(archive, recovered)
        other = Store(recovered)
        try:
            self.assertEqual(other.documents(), self.store.documents())
            self.assertEqual(other.history(doc), self.store.history(doc))
            self.assertEqual(other.requests(), self.store.requests())
            self.assertEqual(other.snapshot(request, "pages"), self.store.snapshot(request, "pages"))
            self.assertEqual(other.revision(original)["body"], "private content")
        finally:
            other.close()
        with self.assertRaises(ValueError): restore(archive, recovered)
        self.assertEqual(archive.stat().st_mode & 0o777, 0o600)
        self.assertEqual(recovered.stat().st_mode & 0o777, 0o600)

    def test_reject_unsafe_or_ambiguous_inputs(self):
        with self.assertRaises(ValueError): Store(self.store.path)
        with self.assertRaises(ValueError): self.store.import_public("pages", {EXTENSION: {}})
        self.store.import_public("pages", {})
        doc, revision = self.store.save("article", "one", "body")
        _, second = self.store.save("article", "two", "body", doc)
        with self.assertRaises(ValueError): self.store.request([], ["pages"])
        with self.assertRaises(ValueError): self.store.request([revision, second], ["pages"])
        with self.assertRaises(ValueError): self.store.request([revision], ["missing"])
        with self.assertRaises(ValueError): self.store.request([revision], ["pages", "pages"])
        source = self.root / "duplicate.json"
        source.write_text('{"history":1,"history":2}')
        with self.assertRaises(ValueError): read_json(source)
        source.write_text('{"value":NaN}')
        with self.assertRaises(ValueError): read_json(source)

    def test_tampered_backup_and_path_traversal_rejected(self):
        archive = self.root / "bad.zip"
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("../database.sqlite3", "bad")
            output.writestr("manifest.json", "{}")
        with self.assertRaises(ValueError): restore(archive, self.root / "new.sqlite3")
        with zipfile.ZipFile(archive, "w") as output:
            output.writestr("database.sqlite3", "bad")
            output.writestr("manifest.json", json.dumps({"format": 1, "sha256": "invalid"}))
        with self.assertRaises(ValueError): restore(archive, self.root / "new.sqlite3")
        self.assertFalse((self.root / "new.sqlite3").exists())


if __name__ == "__main__": unittest.main()
