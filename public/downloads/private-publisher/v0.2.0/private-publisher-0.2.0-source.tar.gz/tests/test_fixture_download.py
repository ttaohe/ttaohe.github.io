import hashlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from scripts import download_fixture as fixture


class Response(io.BytesIO):
    def geturl(self): return "https://example.invalid/synthetic-fixture"


class FixtureDownloadTests(unittest.TestCase):
    def test_verified_download_existing_match_and_corruption(self):
        content = b'{"synthetic":true}'
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'fixture.json'
            with patch.object(fixture, 'EXPECTED_BYTES', len(content)), patch.object(fixture, 'EXPECTED_SHA', hashlib.sha256(content).hexdigest()), patch.object(fixture, 'build_opener') as opener:
                opener.return_value.open.return_value = Response(content)
                self.assertEqual(fixture.download(target), 'downloaded and verified')
                self.assertEqual(target.read_bytes(), content)
                self.assertEqual(fixture.download(target), 'already verified')
                target.write_bytes(b'corrupt')
                with self.assertRaises(ValueError): fixture.download(target)
                self.assertEqual(target.read_bytes(), b'corrupt')

    def test_hash_failure_is_not_saved_and_http_redirect_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'fixture.json'
            with patch.object(fixture, 'EXPECTED_BYTES', 3), patch.object(fixture, 'EXPECTED_SHA', '0'*64), patch.object(fixture, 'build_opener') as opener:
                opener.return_value.open.return_value = Response(b'bad')
                with self.assertRaises(ValueError): fixture.download(target)
            self.assertFalse(target.exists())
            self.assertEqual(list(Path(directory).iterdir()), [])
        with self.assertRaises(ValueError):
            fixture.HTTPSOnlyRedirect().redirect_request(None,None,302,'',{},'http://example.invalid')


if __name__ == '__main__': unittest.main()
