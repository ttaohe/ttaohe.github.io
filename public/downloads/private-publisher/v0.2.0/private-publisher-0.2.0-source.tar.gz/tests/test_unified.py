import io
import json
from pathlib import Path
import tempfile
import unittest
from publisher import file_digest, restore
from unified import UnifiedStore, Scanner, patch_item

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures/content.original.json"
SOURCE_SHA = "ee516cbf6ad9da28e59c87724e57054e8efbfc1e80d12ea539a03f67bfc9d450"


class ScannerTests(unittest.TestCase):
    def test_invalid_and_valid_json(self):
        for raw in [b'{"a":1,"a":2}', b'{"x":NaN}', b'[1,]', b'{"x":"\\q"}', b'{} garbage', b'{"x":1e999}']:
            with self.assertRaises(ValueError): Scanner(io.BytesIO(raw), lambda *args: None).scan()
        for raw in [b' {"x": [true, null, -1.5e2, {"s":"a\\\"b"}]} \n', b'[]']:
            Scanner(io.BytesIO(raw), lambda *args: None).scan()


@unittest.skipUnless(FIXTURE.exists(), "download and verify fixed public fixture first")
class RealCompatibilityTests(unittest.TestCase):
    def test_full_fixture_roundtrip_revision_selection_privacy_conflicts_and_restore(self):
        self.assertEqual(FIXTURE.stat().st_size, 12972715)
        self.assertEqual(file_digest(FIXTURE), SOURCE_SHA)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); store = UnifiedStore(root / "private.sqlite3")
            try:
                baseline = store.import_unified("pages", FIXTURE, SOURCE_SHA)
                counts = dict(store.db.execute("SELECT kind,count(*) FROM u_items WHERE baseline_id=? GROUP BY kind", (baseline,)).fetchall())
                self.assertEqual(counts, {"article": 7, "daily": 876, "experiment": 67})
                noop = store.request_unified([], ["pages"])
                output = root / "roundtrip.json"
                store.export_unified(noop, "pages", output)
                self.assertEqual(file_digest(output), SOURCE_SHA)  # Byte-exact, not just equivalent.
                original = json.loads(FIXTURE.read_bytes())
                key = original["posts"][0]["slug"]
                old = store.revise(baseline, "article", key, [{"path": ["title"], "value": "Selected public revision"}])
                store.revise_private(old, [{"path": ["title"], "value": "PRIVATE_UNSELECTED_NEWER_TITLE"}])
                secret = dict(original["experiments"][0]); secret["id"] = "PRIVATE_UNSELECTED_ID"; secret["title"] = "PRIVATE_UNSELECTED_NEW_DRAFT"
                store.new_private("experiment", secret)
                request = store.request_unified([old], ["pages"])
                output = root / "one-entry.json"
                store.export_unified(request, "pages", output)
                merged = json.loads(output.read_bytes())
                expected = json.loads(FIXTURE.read_bytes()); expected["posts"][0]["title"] = "Selected public revision"
                self.assertEqual(merged, expected)  # Every field, archive and daily metadata compared.
                self.assertNotIn(b"PRIVATE_UNSELECTED", output.read_bytes())
                self.assertNotIn("private_backend_public", merged)
                self.assertEqual(merged["posts"][0]["slug"], key)
                day = "10.09"; item = original["daily"]["reports"][day][0]
                daily = store.revise(baseline, "daily", item["id"], [{"path": ["summary"], "value": "Selected earlier daily version"}], day)
                newer = store.revise_private(daily, [{"path": ["summary"], "value": "PRIVATE_UNSELECTED_DAILY_VERSION"}])
                copied = store.rollback_unified(daily)
                self.assertEqual(store.revision_unified(copied)["payload"], store.revision_unified(daily)["payload"])
                self.assertEqual(len(store.history_unified(newer)), 3)
                daily_request = store.request_unified([daily], ["pages"])
                daily_output = root / "daily.json"
                store.export_unified(daily_request, "pages", daily_output)
                expected = json.loads(FIXTURE.read_bytes()); expected["daily"]["reports"][day][0]["summary"] = "Selected earlier daily version"
                self.assertEqual(json.loads(daily_output.read_bytes()), expected)
                self.assertNotIn(b"PRIVATE_UNSELECTED", daily_output.read_bytes())
                with self.assertRaises(ValueError): store.revise(baseline, "article", key, [{"path": ["slug"], "value": "changed"}])
                with self.assertRaises(ValueError): store.revise(baseline, "article", key, [{"path": ["sections"], "value": []}])
                with self.assertRaises(ValueError): store.request_unified([old, old], ["pages"])
                new_collision = store.new_private("article", original["posts"][0])
                with self.assertRaises(ValueError): store.request_unified([new_collision], ["pages"])
                store.import_unified("pages", output)
                with self.assertRaises(ValueError): store.request_unified([old], ["pages"])
                # Old request retains its exact original baseline after conflicting public import.
                pinned = root / "pinned.json"; store.export_unified(request, "pages", pinned)
                self.assertEqual(file_digest(pinned), file_digest(output))
                backup = root / "backup.zip"; store.backup(backup)
                recovered = root / "recovered.sqlite3"; restore(backup, recovered)
                other = UnifiedStore(recovered)
                try:
                    self.assertEqual(other.private_catalog(), store.private_catalog())
                    self.assertEqual(other.statuses_unified(), store.statuses_unified())
                    self.assertEqual(other.history_unified(daily), store.history_unified(daily))
                    recovered_output = root / "recovered.json"; other.export_unified(daily_request, "pages", recovered_output)
                    self.assertEqual(file_digest(recovered_output), file_digest(daily_output))
                finally: other.close()
            finally: store.close()


if __name__ == "__main__": unittest.main()
