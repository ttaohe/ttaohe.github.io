from http.client import HTTPConnection
from pathlib import Path
import queue
import tempfile
import threading
import unittest
from urllib.parse import urlencode
from publisher import Store
from server import make_server


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.database = Path(self.temp.name) / "private.sqlite3"
        store = Store(self.database)
        store.save("article", "<script>alert(1)</script>", "<img src=x onerror=alert(1)>")
        store.close()
        ready = queue.Queue()
        def run():
            server = make_server(self.database, 0)
            ready.put(server)
            try:
                server.serve_forever(poll_interval=0.05)
            finally:
                server.server_close()
                server.store.close()
        self.thread = threading.Thread(target=run)
        self.thread.start()
        self.server = ready.get(timeout=5)
        self.port = self.server.server_port

    def tearDown(self):
        self.server.shutdown()
        self.thread.join(timeout=5)
        self.temp.cleanup()

    def call(self, method, path, body=None, headers=None):
        connection = HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            connection.request(method, path, body, headers or {})
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read().decode()
        finally:
            connection.close()

    def test_loopback_host_check_and_no_default_selection(self):
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        self.assertEqual(self.call("GET", "/", headers={"Host": "evil.example"})[0], 403)
        status, headers, body = self.call("GET", "/")
        self.assertEqual(status, 200)
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertNotIn("<script>", body)
        self.assertIn("&lt;script&gt;", body)
        self.assertNotIn(" checked", body)

    def test_csrf_rejected_and_valid_local_form_saved(self):
        data = urlencode({"kind": "daily", "title": "new daily", "body": "private text"})
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        self.assertEqual(self.call("POST", "/save", data, headers)[0], 403)
        headers["Origin"] = "https://evil.example"
        self.assertEqual(self.call("POST", "/save", data, headers)[0], 403)
        headers["Origin"] = "http://127.0.0.1:%s" % self.port
        self.assertEqual(self.call("POST", "/save", data, headers)[0], 303)
        self.assertIn("new daily", self.call("GET", "/")[2])

    def test_preview_renders_body_as_text(self):
        status, _, body = self.call("GET", "/revision?id=1")
        self.assertEqual(status, 200)
        self.assertNotIn("<img src=x", body)
        self.assertIn("&lt;img", body)


if __name__ == "__main__": unittest.main()
