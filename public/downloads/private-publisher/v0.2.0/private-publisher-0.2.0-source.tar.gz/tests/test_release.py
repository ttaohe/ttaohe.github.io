import hashlib
import json
import re
from pathlib import Path
import subprocess
import tarfile
import unittest

ROOT=Path(__file__).resolve().parents[1]


class ReleaseTests(unittest.TestCase):
    def test_reproducible_allowlisted_code_only_bundle_and_plan(self):
        subprocess.run(['python3',str(ROOT/'build_release.py')],check=True,capture_output=True)
        bundle=ROOT/'release/private-publisher-0.2.0.tar.gz'
        first=hashlib.sha256(bundle.read_bytes()).hexdigest()
        subprocess.run(['python3',str(ROOT/'build_release.py')],check=True,capture_output=True)
        self.assertEqual(hashlib.sha256(bundle.read_bytes()).hexdigest(),first)
        with tarfile.open(bundle) as archive:
            names=archive.getnames()
            self.assertNotIn('fixtures/content.original.json',names)
            self.assertFalse(any(name.endswith(('.sqlite3','.zip')) for name in names))
            manifest=json.load(archive.extractfile('MANIFEST.json'))
            self.assertEqual(set(names),set(manifest['files'])|{'MANIFEST.json'})
            for name,digest in manifest['files'].items():
                data=archive.extractfile(name).read()
                self.assertEqual(hashlib.sha256(data).hexdigest(),digest)
                self.assertNotIn(b'/Users/',data)
                self.assertFalse(re.search(rb'\b[A-Za-z0-9_-]+\.local\b',data))
                self.assertTrue(all(ip==b'127.0.0.1' for ip in re.findall(rb'\b(?:\d{1,3}\.){3}\d{1,3}\b',data)))
                self.assertNotIn(b'PRIVATE_UNSELECTED',data)
        for script in (ROOT/'scripts').glob('*.sh'):
            subprocess.run(['sh','-n',str(script)],check=True)
        result=subprocess.run(['sh',str(ROOT/'scripts/install.sh'),'--plan'],check=True,capture_output=True,text=True)
        self.assertIn('listen=127.0.0.1:8080',result.stdout)


if __name__=='__main__': unittest.main()
