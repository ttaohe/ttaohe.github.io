#!/bin/sh
set -eu
python3 - <<'PY'
from http.client import HTTPConnection
import time
for attempt in range(20):
 try:
  c=HTTPConnection('127.0.0.1',8080,timeout=2)
  c.request('GET','/health'); r=c.getresponse(); body=r.read(); break
 except OSError:
  c.close()
  if attempt == 19: raise
  time.sleep(0.2)
if r.status != 200 or b'healthy' not in body: raise SystemExit('Health check failed')
c.close()
c=HTTPConnection('127.0.0.1',8080,timeout=5)
c.request('GET','/health',headers={'Host':'untrusted.example'})
if c.getresponse().status != 403: raise SystemExit('Host protection failed')
c.close(); print('Loopback HTTP healthy; untrusted Host rejected')
PY
