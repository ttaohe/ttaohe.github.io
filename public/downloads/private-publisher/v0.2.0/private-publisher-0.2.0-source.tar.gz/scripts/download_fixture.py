"""Explicit opt-in read-only download of one pinned public JSON test fixture."""
import argparse
import hashlib
import os
from pathlib import Path
import tempfile
from urllib.request import HTTPRedirectHandler, build_opener

URL = "https://raw.githubusercontent.com/ttaohe/ttaohe.github.io/6fdfa533781642a69e8931df6eafaa10250e5938/lib/blog/content.json"
EXPECTED_SHA = "ee516cbf6ad9da28e59c87724e57054e8efbfc1e80d12ea539a03f67bfc9d450"
EXPECTED_BYTES = 12972715


class HTTPSOnlyRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        if not new_url.startswith("https://"):
            raise ValueError("HTTPS-only download")
        return super().redirect_request(request, response, code, message, headers, new_url)


def checksum(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""): digest.update(chunk)
    return digest.hexdigest()


def download(destination):
    destination = Path(destination)
    if destination.exists():
        if destination.is_symlink() or destination.stat().st_size != EXPECTED_BYTES or checksum(destination) != EXPECTED_SHA:
            raise ValueError("existing fixture differs: refusing to overwrite")
        return "already verified"
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".fixture-", dir=str(destination.parent))
    temporary = Path(name)
    try:
        digest = hashlib.sha256(); size = 0
        with os.fdopen(fd, "wb") as target, build_opener(HTTPSOnlyRedirect()).open(URL, timeout=30) as source:
            if not source.geturl().startswith("https://"): raise ValueError("HTTPS required")
            while True:
                chunk = source.read(65536)
                if not chunk: break
                size += len(chunk)
                if size > EXPECTED_BYTES: raise ValueError("fixture exceeds pinned size")
                digest.update(chunk); target.write(chunk)
        if size != EXPECTED_BYTES or digest.hexdigest() != EXPECTED_SHA:
            raise ValueError("fixture size/SHA-256 verification failed")
        os.link(temporary, destination)  # Exclusive commit: cannot overwrite a racing file.
        return "downloaded and verified"
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", default="fixtures/content.original.json")
    args = parser.parse_args()
    print(download(args.destination)); print("SHA-256:", EXPECTED_SHA)
