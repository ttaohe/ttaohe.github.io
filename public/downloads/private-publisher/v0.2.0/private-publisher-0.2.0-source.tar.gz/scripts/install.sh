#!/bin/sh
# Reviewed local code installation only. No public ports, credentials or downloads.
set -eu
SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PREFIX=${PP_PREFIX:-/opt/private-publisher}
DATA=${PP_DATA:-/var/lib/private-publisher}
SERVICE=private-publisher.service
ACCOUNT=privatepublisher
VERSION=$(cat "$SOURCE/VERSION")
case "$VERSION" in ''|*[!0-9.]* ) echo 'Invalid version' >&2; exit 1;; esac
for directory in "$PREFIX" "$DATA"; do
    case "$directory" in /*) ;; *) echo 'Absolute paths required' >&2; exit 1;; esac
    case "$directory" in *[!A-Za-z0-9/_-]*|/|*/../*|*/./*|*/..) echo 'Unsafe directory' >&2; exit 1;; esac
done
python3 - "$SOURCE" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); manifest=json.loads((root/'MANIFEST.json').read_text())
if manifest['version'] != (root/'VERSION').read_text().strip(): raise SystemExit('Version mismatch')
for name,digest in manifest['files'].items():
    p=Path(name)
    if p.is_absolute() or '..' in p.parts or (root/p).is_symlink(): raise SystemExit('Unsafe file')
    if hashlib.sha256((root/p).read_bytes()).hexdigest() != digest: raise SystemExit('Code hash mismatch')
print('Verified code manifest',manifest['version'])
PY
if [ "${1:-}" = '--plan' ]; then
    printf 'version=%s\naccount=%s\nprefix=%s\ndata=%s\nlisten=127.0.0.1:8080\n' "$VERSION" "$ACCOUNT" "$PREFIX" "$DATA"
    exit 0
fi
case "${1:-}" in ''|--start) ;; *) echo 'Usage: install.sh [--plan|--start]' >&2; exit 1;; esac
[ "$(id -u)" -eq 0 ] || { echo 'Root required for approved account/service installation' >&2; exit 1; }
[ -x /usr/bin/python3 ] && [ -x /usr/bin/systemctl ] && [ -x /usr/sbin/runuser ] || { echo 'Python/systemd/runuser missing; no software will be installed' >&2; exit 1; }
python3 -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ required"'
if getent passwd "$ACCOUNT" >/dev/null; then
    ENTRY=$(getent passwd "$ACCOUNT")
    EXISTING_HOME=$(printf '%s\n' "$ENTRY" | cut -d: -f6)
    EXISTING_SHELL=$(printf '%s\n' "$ENTRY" | cut -d: -f7)
    [ "$EXISTING_HOME" = "$DATA" ] && [ "$EXISTING_SHELL" = /usr/sbin/nologin ] || { echo 'Existing account does not match managed service identity' >&2; exit 1; }
else
    useradd --system --user-group --no-create-home --home-dir "$DATA" --shell /usr/sbin/nologin "$ACCOUNT"
fi
mkdir -p "$PREFIX/releases" "$DATA/backups"
chmod 700 "$DATA" "$DATA/backups"
chown "$ACCOUNT:$ACCOUNT" "$DATA" "$DATA/backups"
RELEASE="$PREFIX/releases/$VERSION"
if [ -e "$RELEASE" ]; then
    cmp "$SOURCE/MANIFEST.json" "$RELEASE/MANIFEST.json" || { echo 'Version already installed with different content; choose a new version' >&2; exit 1; }
else
    mkdir "$RELEASE"
    python3 - "$SOURCE" "$RELEASE" <<'PY'
import json,shutil,sys
from pathlib import Path
source,target=map(Path,sys.argv[1:]); files=list(json.loads((source/'MANIFEST.json').read_text())['files'])+['MANIFEST.json']
for name in files:
    dest=target/name; dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source/name,dest); dest.chmod(0o755 if name.endswith('.sh') else 0o644)
PY
fi
UNIT=/etc/systemd/system/private-publisher.service
if [ -e "$UNIT" ] && ! head -n 1 "$UNIT" | grep -qx '# Managed private-publisher loopback prototype'; then
    echo 'Refusing to replace an unrelated service unit' >&2; exit 1
fi
if systemctl is-active --quiet "$SERVICE"; then
    echo 'Stop the managed service before switching code; existing service kept running' >&2; exit 1
fi
ln -s "$RELEASE" "$PREFIX/.current-new"
mv -Tf "$PREFIX/.current-new" "$PREFIX/current"
cat > "$UNIT" <<EOF
# Managed private-publisher loopback prototype
[Unit]
Description=Private publisher loopback prototype
After=network.target
[Service]
Type=simple
User=$ACCOUNT
Group=$ACCOUNT
WorkingDirectory=$PREFIX/current
Environment=PYTHONDONTWRITEBYTECODE=1
ExecStart=/usr/bin/python3 $PREFIX/current/unified_server.py --db $DATA/private.sqlite3 --port 8080
UMask=0077
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$DATA
RestrictAddressFamilies=AF_UNIX AF_INET
MemoryHigh=64M
MemoryMax=80M
TasksMax=16
CPUQuota=50%
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
printf 'Installed %s; not enabled for boot.\n' "$VERSION"
if [ "${1:-}" = '--start' ]; then
    python3 - <<'PY'
import socket
s=socket.socket(); s.bind(('127.0.0.1',8080)); s.close()
PY
    systemctl start "$SERVICE"
    "$RELEASE/scripts/health.sh"
fi
