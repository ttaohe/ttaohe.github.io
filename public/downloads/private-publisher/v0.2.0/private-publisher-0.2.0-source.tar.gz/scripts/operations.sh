#!/bin/sh
# Stop UI before CLI operations: application lock enforces one writer process.
set -eu
PREFIX=${PP_PREFIX:-/opt/private-publisher}
DATA=${PP_DATA:-/var/lib/private-publisher}
ACCOUNT=privatepublisher
SERVICE=private-publisher.service
[ "$(id -u)" -eq 0 ] || { echo 'Root required for service maintenance' >&2; exit 1; }
for directory in "$PREFIX" "$DATA"; do
 case "$directory" in /*) ;; *) exit 1;; esac
 case "$directory" in *[!A-Za-z0-9/_-]*|/|*/../*|*/./*|*/..) exit 1;; esac
done
ACTION=${1:-}
case "$ACTION" in
 start) systemctl start "$SERVICE"; "$PREFIX/current/scripts/health.sh"; exit;;
 stop) systemctl stop "$SERVICE"; exit;;
 health) "$PREFIX/current/scripts/health.sh"; exit;;
 backup|restore|cli) ;;
 *) echo 'Usage: operations.sh start|stop|health|backup NAME.zip|restore NAME.zip|cli ARGS...' >&2; exit 1;;
esac
WAS_ACTIVE=no
if systemctl is-active --quiet "$SERVICE"; then WAS_ACTIVE=yes; fi
systemctl stop "$SERVICE"
restart() { if [ "$WAS_ACTIVE" = yes ]; then systemctl start "$SERVICE"; fi; }
trap restart EXIT
shift
case "$ACTION" in
 backup|restore)
  NAME=${1:-}
  case "$NAME" in ''|*[!A-Za-z0-9._-]*|.*) echo 'Use a simple backup filename' >&2; exit 1;; esac
  ARCHIVE="$DATA/backups/$NAME"
  if [ "$ACTION" = backup ]; then
   runuser -u "$ACCOUNT" -- env PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 "$PREFIX/current/unified.py" --db "$DATA/private.sqlite3" backup "$ARCHIVE"
  else
   STAMP=$(date -u +%Y%m%dT%H%M%SZ)
   NEW="$DATA/restored-$STAMP.sqlite3"
   runuser -u "$ACCOUNT" -- env PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 "$PREFIX/current/unified.py" restore "$ARCHIVE" "$NEW"
   if [ -f "$DATA/private.sqlite3" ]; then mv "$DATA/private.sqlite3" "$DATA/before-restore-$STAMP.sqlite3"; fi
   mv "$NEW" "$DATA/private.sqlite3"
  fi;;
 cli)
  runuser -u "$ACCOUNT" -- env PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 "$PREFIX/current/unified.py" --db "$DATA/private.sqlite3" "$@";;
esac
