#!/bin/sh
# Code rollback only. Never silently roll back private data or schema.
set -eu
PREFIX=${PP_PREFIX:-/opt/private-publisher}
VERSION=${1:-}
case "$PREFIX" in /*) ;; *) exit 1;; esac
case "$PREFIX" in *[!A-Za-z0-9/_-]*|/|*/../*|*/./*|*/..) exit 1;; esac
case "$VERSION" in ''|*[!0-9.]* ) echo 'Explicit previously installed version required' >&2; exit 1;; esac
[ "$(id -u)" -eq 0 ] || { echo 'Root required' >&2; exit 1; }
TARGET="$PREFIX/releases/$VERSION"
[ -f "$TARGET/MANIFEST.json" ] || { echo 'Version not installed' >&2; exit 1; }
systemctl stop private-publisher.service
ln -s "$TARGET" "$PREFIX/.current-new"
mv -Tf "$PREFIX/.current-new" "$PREFIX/current"
systemctl start private-publisher.service
"$TARGET/scripts/health.sh"
