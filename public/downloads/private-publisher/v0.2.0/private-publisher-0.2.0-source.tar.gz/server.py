"""Loopback-only prototype UI. No production authentication or publishing client."""
import argparse
import html
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlsplit
from publisher import Store, KINDS


def escape(value):
    return html.escape(str(value), quote=True)


class Handler(BaseHTTPRequestHandler):
    # Deliberately omit request paths, document text and client input from logs.
    def log_message(self, *_):
        pass

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def allowed_host(self):
        port = self.server.server_port
        return self.headers.get("Host") in {"127.0.0.1:%s" % port, "localhost:%s" % port}

    def page(self, body, status=200):
        data = ("<!doctype html><html lang='zh'><meta charset='utf-8'>"
                "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                "<title>私有发布后台原型</title><body><h1>私有发布后台原型</h1>"
                "<p>本机回环测试 · 无自动发布 · 公开快照需经现有发布通路处理</p>"
                + body + "</body></html>").encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", "default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self.allowed_host():
            self.page("Host rejected", 403)
            return
        query = urlsplit(self.path)
        store = self.server.store
        try:
            if query.path == "/revision":
                revision = store.revision(int(parse_qs(query.query)["id"][0]))
                body = "<p><a href='/'>返回</a></p><h2>%s</h2><pre>%s</pre>" % (
                    escape(revision["title"]), escape(revision["body"]))
                body += "<p>版本 %s · %s</p>" % (revision["id"], escape(revision["created"]))
                body += "<form method='post' action='/rollback'><input type='hidden' name='revision' value='%s'><button>以此版本创建新的当前版本</button></form>" % revision["id"]
                body += "<h3>修改并保存新版本</h3><form method='post' action='/save'>"
                body += "<input type='hidden' name='document' value='%s'><input type='hidden' name='kind' value='%s'>" % (revision["document_id"], escape(revision["kind"]))
                body += "<input name='title' required value='%s'><br><textarea name='body' rows='16' cols='80'>%s</textarea><br><button>保存私有版本</button></form>" % (escape(revision["title"]), escape(revision["body"]))
                body += "<h3>版本历史</h3><ul>"
                for row in store.history(revision["document_id"]):
                    body += "<li><a href='/revision?id=%s'>版本 %s · %s</a></li>" % (row["id"], row["id"], escape(row["created"]))
                self.page(body + "</ul>")
            elif query.path == "/":
                body = "<h2>新私有草稿</h2><form method='post' action='/save'><select name='kind'>"
                for kind in sorted(KINDS):
                    body += "<option>%s</option>" % kind
                body += "</select><input name='title' placeholder='标题' required><br><textarea name='body' rows='12' cols='80' placeholder='纯文本正文'></textarea><br><button>保存私有草稿</button></form>"
                body += "<h2>逐项选择公开版本</h2><p>默认不选中任何草稿。发布请求固定所选版本，后续编辑不改变该请求。</p><form method='post' action='/request'>"
                for row in store.documents():
                    body += "<p><label><input type='checkbox' name='revision' value='%s'>%s · %s</label> <a href='/revision?id=%s'>预览 / 编辑 / 历史</a></p>" % (
                        row["revision_id"], escape(row["kind"]), escape(row["title"]), row["revision_id"])
                sites = store.db.execute("SELECT DISTINCT site FROM baselines ORDER BY site").fetchall()
                body += "<h3>目标站点</h3>"
                for row in sites:
                    body += "<label><input type='checkbox' name='site' value='%s'>%s</label><br>" % (escape(row["site"]), escape(row["site"]))
                body += "<button>创建发布请求（仅记录，不自动发布）</button></form>"
                body += "<h2>每站状态</h2><table><tr><th>请求</th><th>站点</th><th>状态</th><th>备注</th></tr>"
                for row in store.requests():
                    body += "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (row["request_id"], escape(row["site"]), escape(row["status"]), escape(row["detail"] or ""))
                self.page(body + "</table><p>基线导入、快照导出、人工发布结果及完整备份恢复：使用本地 CLI。</p>")
            else:
                self.page("Not found", 404)
        except (ValueError, KeyError):
            self.page("Invalid request", 400)

    def do_POST(self):
        # Browser forms must come from this same loopback origin. No generated secret.
        if not self.allowed_host() or self.headers.get("Origin") != "http://" + self.headers.get("Host", ""):
            self.page("Origin rejected", 403)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 280 * 1024 or self.headers.get("Transfer-Encoding"):
                raise ValueError("invalid request size")
            if self.headers.get("Content-Type", "").split(";")[0] != "application/x-www-form-urlencoded":
                raise ValueError("unsupported content type")
            data = self.rfile.read(length)
            if len(data) != length:
                raise ValueError("incomplete request")
            form = parse_qs(data.decode("utf-8"), keep_blank_values=True, max_num_fields=1024)
            store = self.server.store
            if self.path == "/save":
                document = form.get("document", [""])[0]
                store.save(form["kind"][0], form["title"][0], form["body"][0], int(document) if document else None)
            elif self.path == "/rollback":
                store.rollback(int(form["revision"][0]))
            elif self.path == "/request":
                store.request([int(value) for value in form.get("revision", [])], form.get("site", []))
            else:
                self.page("Not found", 404)
                return
            self.send_response(303)
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.end_headers()
        except (ValueError, KeyError, UnicodeError):
            self.page("Invalid request: select revisions and sites, or check input", 400)


def make_server(database, port=8080):
    server = HTTPServer(("127.0.0.1", port), Handler)
    server.store = Store(database)
    return server


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="data/private.sqlite3")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    server = make_server(args.db, args.port)
    print("Prototype listening on http://127.0.0.1:%s" % server.server_port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        server.store.close()
