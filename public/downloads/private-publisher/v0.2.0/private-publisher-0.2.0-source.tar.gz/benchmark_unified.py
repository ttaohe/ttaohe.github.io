"""Measure actual public fixture with bounded-memory production adapter."""
import resource
import sys
import tempfile
from pathlib import Path
from unified import UnifiedStore
from publisher import file_digest, restore

source = Path(__file__).resolve().parent / "fixtures/content.original.json"
expected = "ee516cbf6ad9da28e59c87724e57054e8efbfc1e80d12ea539a03f67bfc9d450"
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory); store = UnifiedStore(root / "private.sqlite3")
    baseline = store.import_unified("pages", source, expected)
    row = store.catalog(baseline, "article", limit=1)[0]
    selected = store.revise(baseline, "article", row["key"], [{"path": ["title"], "value": "Synthetic selected title"}])
    store.revise_private(selected, [{"path": ["title"], "value": "PRIVATE_UNSELECTED_SYNTHETIC_TITLE"}])
    request = store.request_unified([selected], ["pages"])
    result = store.export_unified(request, "pages", root / "snapshot.json")
    # Exercise largest actual item, including its historical archive.
    biggest = store.db.execute("SELECT kind,day,key FROM u_items WHERE baseline_id=? ORDER BY end-start DESC LIMIT 1", (baseline,)).fetchone()
    store.revise(baseline, biggest["kind"], biggest["key"], [{"path": ["title"], "value": "Synthetic largest item title"}], biggest["day"])
    store.backup(root / "backup.zip"); restore(root / "backup.zip", root / "restored.sqlite3")
    print("Actual fixture bytes:", source.stat().st_size)
    print("Source SHA-256:", file_digest(source))
    print("Export:", result)
    print("Database bytes:", store.path.stat().st_size)
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    print("Peak RSS bytes:", rss if sys.platform == "darwin" else rss * 1024)
    store.close()
